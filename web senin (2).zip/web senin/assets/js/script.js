// JavaScript untuk Website Restoran

document.addEventListener('DOMContentLoaded', function() {
    // Inisialisasi tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Fungsi untuk update quantity
    function updateQuantity(menuId, change) {
        const input = document.getElementById(`quantity-${menuId}`);
        const currentValue = parseInt(input.value) || 0;
        const newValue = Math.max(0, currentValue + change);
        input.value = newValue;
        updateCart(menuId, newValue);
    }

    // Fungsi untuk update cart
    function updateCart(menuId, quantity) {
        if (window.isUserLoggedIn) {
            fetch('/web%20senin/user/cart_action.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `menu_id=${menuId}&quantity=${quantity}`
            })
            .then(res => res.json())
            .then(data => {
                if (!data.success) {
                    alert(data.message || 'Gagal update keranjang!');
                } else {
                    window.location.reload(); // reload agar cart.php ambil data terbaru dari database
                }
            })
            .catch(err => {
                alert('Gagal komunikasi dengan server!');
            });
        } else {
            // Tetap pakai localStorage untuk guest
            const cartItems = JSON.parse(localStorage.getItem('cartItems')) || {};
            if (quantity > 0) {
                cartItems[menuId] = quantity;
            } else {
                delete cartItems[menuId];
            }
            localStorage.setItem('cartItems', JSON.stringify(cartItems));
            updateCartDisplay();
        }
    }

    // Fungsi untuk menampilkan cart
    function updateCartDisplay() {
        if (window.isUserLoggedIn) {
            // Untuk user login, biarkan PHP yang render keranjang
            return;
        }
        const cartItems = JSON.parse(localStorage.getItem('cartItems')) || {};
        const cartCount = Object.keys(cartItems).length;
        
        // Update cart badge
        const cartBadge = document.getElementById('cart-badge');
        if (cartBadge) {
            cartBadge.textContent = cartCount;
            cartBadge.style.display = cartCount > 0 ? 'inline' : 'none';
        }
        
        // Update cart summary jika ada
        const cartSummary = document.getElementById('cart-summary');
        if (cartSummary) {
            displayCartSummary(cartItems);
        }
    }

    // Fungsi untuk menampilkan cart summary
    function displayCartSummary(cartItems) {
        if (window.isUserLoggedIn) {
            // Untuk user login, biarkan PHP yang render keranjang
            return;
        }
        const cartSummary = document.getElementById('cart-summary');
        if (!cartSummary) return;

        let html = '<h5 class="mb-3">Keranjang Belanja</h5>';
        let total = 0;

        if (Object.keys(cartItems).length === 0) {
            html += '<p class="text-muted">Keranjang kosong</p>';
        } else {
            html += '<div class="cart-items">';
            
            // Ambil data menu dari halaman
            const menuCards = document.querySelectorAll('.menu-card');
            menuCards.forEach(card => {
                const menuId = card.dataset.menuId;
                const quantity = cartItems[menuId];
                
                if (quantity && quantity > 0) {
                    const menuName = card.querySelector('.card-title').textContent;
                    const menuPrice = parseFloat(card.dataset.price);
                    const subtotal = menuPrice * quantity;
                    total += subtotal;
                    
                    html += `
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <small class="fw-bold">${menuName}</small><br>
                                <small class="text-muted">${quantity}x @ ${formatPrice(menuPrice)}</small>
                            </div>
                            <small class="fw-bold">${formatPrice(subtotal)}</small>
                        </div>
                    `;
                }
            });
            
            html += '</div>';
            html += `<hr><div class="d-flex justify-content-between align-items-center">
                        <strong>Total:</strong>
                        <strong class="text-primary">${formatPrice(total)}</strong>
                    </div>`;
            html += `<button class="btn btn-primary w-100 mt-3" onclick="checkout()">Checkout</button>`;
        }
        
        cartSummary.innerHTML = html;
    }

    // Fungsi untuk format harga
    function formatPrice(price) {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0
        }).format(price);
    }

    // Fungsi checkout
    window.checkout = function() {
        const cartItems = JSON.parse(localStorage.getItem('cartItems')) || {};
        
        if (Object.keys(cartItems).length === 0) {
            alert('Keranjang belanja kosong!');
            return;
        }
        
        // Redirect ke halaman checkout
        window.location.href = 'checkout.php';
    }

    // Event listeners untuk quantity buttons
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('quantity-btn')) {
            const menuId = e.target.dataset.menuId;
            const change = e.target.dataset.change === 'increase' ? 1 : -1;
            updateQuantity(menuId, change);
        }
    });

    // Event listeners untuk quantity input
    document.addEventListener('change', function(e) {
        if (e.target.classList.contains('quantity-input')) {
            const menuId = e.target.dataset.menuId;
            const quantity = parseInt(e.target.value) || 0;
            updateCart(menuId, quantity);
        }
    });

    // Validasi form login
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            
            if (!email || !password) {
                e.preventDefault();
                alert('Mohon isi semua field yang diperlukan!');
                return false;
            }
            
            if (!isValidEmail(email)) {
                e.preventDefault();
                alert('Format email tidak valid!');
                return false;
            }
        });
    }

    // Validasi form register
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            const username = document.getElementById('username').value;
            const email = document.getElementById('email').value;
            const password = document.getElementById('password').value;
            const confirmPassword = document.getElementById('confirm_password').value;
            
            if (!username || !email || !password || !confirmPassword) {
                e.preventDefault();
                alert('Mohon isi semua field yang diperlukan!');
                return false;
            }
            
            if (!isValidEmail(email)) {
                e.preventDefault();
                alert('Format email tidak valid!');
                return false;
            }
            
            if (password.length < 6) {
                e.preventDefault();
                alert('Password minimal 6 karakter!');
                return false;
            }
            
            if (password !== confirmPassword) {
                e.preventDefault();
                alert('Konfirmasi password tidak cocok!');
                return false;
            }
        });
    }

    // Validasi form menu (admin)
    const menuForm = document.getElementById('menuForm');
    if (menuForm) {
        menuForm.addEventListener('submit', function(e) {
            const nama = document.getElementById('nama').value;
            const harga = document.getElementById('harga').value;
            const kategori = document.getElementById('kategori').value;
            
            if (!nama || !harga || !kategori) {
                e.preventDefault();
                alert('Mohon isi semua field yang diperlukan!');
                return false;
            }
            
            if (isNaN(harga) || parseFloat(harga) <= 0) {
                e.preventDefault();
                alert('Harga harus berupa angka positif!');
                return false;
            }
        });
    }

    // Fungsi validasi email
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    // Auto-hide alerts
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(alert => {
        setTimeout(() => {
            alert.style.opacity = '0';
            setTimeout(() => {
                alert.remove();
            }, 300);
        }, 5000);
    });

    // Preview image upload
    const imageInput = document.getElementById('gambar');
    if (imageInput) {
        imageInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const preview = document.getElementById('image-preview');
                    if (preview) {
                        preview.src = e.target.result;
                        preview.style.display = 'block';
                    }
                };
                reader.readAsDataURL(file);
            }
        });
    }

    // Search functionality
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.addEventListener('input', function(e) {
            const searchTerm = e.target.value.toLowerCase();
            const menuCards = document.querySelectorAll('.menu-card');
            
            menuCards.forEach(card => {
                const menuName = card.querySelector('.card-title').textContent.toLowerCase();
                const menuDesc = card.querySelector('.card-text').textContent.toLowerCase();
                
                if (menuName.includes(searchTerm) || menuDesc.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }

    // Filter by category
    const categoryFilter = document.getElementById('categoryFilter');
    if (categoryFilter) {
        categoryFilter.addEventListener('change', function(e) {
            const selectedCategory = e.target.value;
            const menuCards = document.querySelectorAll('.menu-card');
            
            menuCards.forEach(card => {
                const menuCategory = card.dataset.category;
                
                if (selectedCategory === 'all' || menuCategory === selectedCategory) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        });
    }

    // Initialize cart display
    updateCartDisplay();
});

// Fungsi untuk konfirmasi delete
function confirmDelete(message = 'Apakah Anda yakin ingin menghapus item ini?') {
    return confirm(message);
}

// Fungsi untuk update order status
function updateOrderStatus(orderId, status) {
    if (confirm('Apakah Anda yakin ingin mengubah status pesanan ini?')) {
        fetch('admin/update_order_status.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `order_id=${orderId}&status=${status}`
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            } else {
                alert('Gagal mengubah status pesanan!');
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Terjadi kesalahan!');
        });
    }
} 