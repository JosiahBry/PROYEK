<?php
require_once 'includes/functions.php';

// Hapus semua session
session_destroy();

// Redirect ke halaman utama
redirect('index.php');
?> 