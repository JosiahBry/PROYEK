<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login dan role admin
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

$menu_id = $_GET['id'] ?? null;

if (!$menu_id) {
    showAlert('ID menu tidak valid!', 'danger');
    redirect('menu.php');
}

try {
    // Ambil data menu untuk hapus gambar
    $stmt = $pdo->prepare("SELECT gambar FROM menu WHERE id = ?");
    $stmt->execute([$menu_id]);
    $menu = $stmt->fetch();
    
    if (!$menu) {
        showAlert('Menu tidak ditemukan!', 'danger');
        redirect('menu.php');
    }
    
    // Hapus menu dari database
    $stmt = $pdo->prepare("DELETE FROM menu WHERE id = ?");
    $result = $stmt->execute([$menu_id]);
    
    if ($result) {
        // Hapus file gambar jika ada
        if ($menu['gambar']) {
            $image_path = '../assets/images/menu/' . $menu['gambar'];
            if (file_exists($image_path)) {
                unlink($image_path);
            }
        }
        
        showAlert('Menu berhasil dihapus!', 'success');
    } else {
        showAlert('Gagal menghapus menu!', 'danger');
    }
    
} catch (PDOException $e) {
    showAlert('Terjadi kesalahan sistem!', 'danger');
}

redirect('menu.php');
?> 