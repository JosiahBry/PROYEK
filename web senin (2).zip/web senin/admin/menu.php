<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login dan role admin
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

// Ambil data menu
try {
    $stmt = $pdo->query("SELECT * FROM menu ORDER BY created_at DESC");
    $menu_list = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Terjadi kesalahan sistem!';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Menu - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script>window.isUserLoggedIn = true;</script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Admin Dashboard
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i>
                            Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payment_methods.php">
                            <i class="bi bi-credit-card me-1"></i>
                            Metode Pembayaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="bi bi-people me-1"></i>
                            Users
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-list-ul me-2"></i>
                Manajemen Menu
            </h2>
            <a href="menu_add.php" class="btn btn-primary">
                <i class="bi bi-plus-circle me-2"></i>
                Tambah Menu
            </a>
        </div>

        <!-- Menu List -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($menu_list)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-list-ul text-muted" style="font-size: 3rem;"></i>
                        <p class="text-muted mt-3">Belum ada menu</p>
                        <a href="menu_add.php" class="btn btn-primary">Tambah Menu Pertama</a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Gambar</th>
                                    <th>Nama Menu</th>
                                    <th>Kategori</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Tanggal Dibuat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($menu_list as $menu): ?>
                                    <tr>
                                        <td>
                                            <?php if ($menu['gambar']): ?>
                                                <img src="../assets/images/menu/<?php echo $menu['gambar']; ?>" 
                                                     alt="<?php echo htmlspecialchars($menu['nama']); ?>" 
                                                     class="img-thumbnail" style="width: 50px; height: 50px; object-fit: cover;">
                                            <?php else: ?>
                                                <div class="bg-light d-flex align-items-center justify-content-center" 
                                                     style="width: 50px; height: 50px;">
                                                    <i class="bi bi-image text-muted"></i>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($menu['nama']); ?></strong>
                                            <?php if ($menu['deskripsi']): ?>
                                                <br>
                                                <small class="text-muted"><?php echo htmlspecialchars(substr($menu['deskripsi'], 0, 50)); ?>...</small>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <span class="category-badge">
                                                <?php echo ucfirst($menu['kategori']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <span class="price"><?php echo formatPrice($menu['harga']); ?></span>
                                        </td>
                                        <td>
                                            <?php if ($menu['status'] == 'tersedia'): ?>
                                                <span class="badge bg-success">Tersedia</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">Tidak Tersedia</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($menu['created_at'])); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="menu_edit.php?id=<?php echo $menu['id']; ?>" 
                                                   class="btn btn-sm btn-outline-primary" 
                                                   data-bs-toggle="tooltip" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#deleteMenuModal" 
                                                        data-menu-id="<?php echo $menu['id']; ?>" 
                                                        data-menu-name="<?php echo htmlspecialchars($menu['nama']); ?>"
                                                        title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal Konfirmasi Hapus Menu -->
    <div class="modal fade" id="deleteMenuModal" tabindex="-1" aria-labelledby="deleteMenuModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="GET" action="menu_delete.php">
            <input type="hidden" name="id" id="deleteMenuId">
            <div class="modal-header bg-danger">
              <h5 class="modal-title" id="deleteMenuModalLabel"><i class="bi bi-exclamation-triangle me-2"></i>Konfirmasi Hapus Menu</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda yakin ingin menghapus menu <strong id="deleteMenuName"></strong>?</p>
              <p class="text-danger mb-0">Tindakan ini tidak dapat dibatalkan!</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-danger">Hapus</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        function deleteMenu(menuId, menuName) {
            if (confirmDelete(`Apakah Anda yakin ingin menghapus menu "${menuName}"?`)) {
                window.location.href = `menu_delete.php?id=${menuId}`;
            }
        }
    </script>
    <script>
      var deleteMenuModal = document.getElementById('deleteMenuModal');
      deleteMenuModal.addEventListener('show.bs.modal', function (event) {
        var button = event.relatedTarget;
        var menuId = button.getAttribute('data-menu-id');
        var menuName = button.getAttribute('data-menu-name');
        var modalMenuId = deleteMenuModal.querySelector('#deleteMenuId');
        var modalMenuName = deleteMenuModal.querySelector('#deleteMenuName');
        modalMenuId.value = menuId;
        modalMenuName.textContent = menuName;
      });
    </script>
</body>
</html> 