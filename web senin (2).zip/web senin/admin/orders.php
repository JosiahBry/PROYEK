<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login dan role admin
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

// Filter status
$status_filter = $_GET['status'] ?? 'all';
$payment_status_filter = $_GET['payment_status'] ?? 'all';

// Ambil data pesanan
try {
    $where_conditions = ["1=1"];
    $params = [];
    
    if ($status_filter != 'all') {
        $where_conditions[] = "o.status = ?";
        $params[] = $status_filter;
    }
    
    if ($payment_status_filter != 'all') {
        $where_conditions[] = "o.payment_status = ?";
        $params[] = $payment_status_filter;
    }
    
    $where_clause = implode(' AND ', $where_conditions);
    $sql = "
        SELECT o.*, u.username, u.email, pm.nama as payment_method_name, pm.icon as payment_icon, COUNT(oi.id) as item_count 
        FROM orders o 
        JOIN users u ON o.user_id = u.id 
        LEFT JOIN payment_methods pm ON o.payment_method_id = pm.id
        LEFT JOIN order_items oi ON o.id = oi.order_id 
        WHERE $where_clause 
        GROUP BY o.id 
        ORDER BY o.created_at DESC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $orders = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = 'Terjadi kesalahan sistem!';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Pesanan - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .payment-status-badge {
            font-size: 0.75rem;
        }
        
        .payment-method-info {
            display: flex;
            align-items: center;
            gap: 5px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Admin Dashboard
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i>
                            Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="payment_methods.php">
                            <i class="bi bi-credit-card me-1"></i>
                            Metode Pembayaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="bi bi-people me-1"></i>
                            Users
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-cart me-2"></i>
                Manajemen Pesanan
            </h2>
        </div>

        <!-- Filter -->
        <div class="row mb-4">
            <div class="col-md-8">
                <form method="GET" action="" class="d-flex gap-2">
                    <select class="form-select" name="status">
                        <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>Semua Status Pesanan</option>
                        <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="diproses" <?php echo $status_filter == 'diproses' ? 'selected' : ''; ?>>Diproses</option>
                        <option value="selesai" <?php echo $status_filter == 'selesai' ? 'selected' : ''; ?>>Selesai</option>
                        <option value="dibatalkan" <?php echo $status_filter == 'dibatalkan' ? 'selected' : ''; ?>>Dibatalkan</option>
                    </select>
                    <select class="form-select" name="payment_status">
                        <option value="all" <?php echo $payment_status_filter == 'all' ? 'selected' : ''; ?>>Semua Status Pembayaran</option>
                        <option value="pending" <?php echo $payment_status_filter == 'pending' ? 'selected' : ''; ?>>Menunggu Pembayaran</option>
                        <option value="paid" <?php echo $payment_status_filter == 'paid' ? 'selected' : ''; ?>>Sudah Dibayar</option>
                        <option value="failed" <?php echo $payment_status_filter == 'failed' ? 'selected' : ''; ?>>Gagal</option>
                        <option value="refunded" <?php echo $payment_status_filter == 'refunded' ? 'selected' : ''; ?>>Dikembalikan</option>
                    </select>
                    <button type="submit" class="btn btn-outline-primary">Filter</button>
                    <a href="orders.php" class="btn btn-outline-secondary">Reset</a>
                </form>
            </div>
        </div>

        <!-- Orders List -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($orders)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-cart-x text-muted" style="font-size: 3rem;"></i>
                        <p class="text-muted mt-3">Belum ada pesanan</p>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>ID Pesanan</th>
                                    <th>Customer</th>
                                    <th>Item</th>
                                    <th>Total</th>
                                    <th>Metode Pembayaran</th>
                                    <th>Status Pesanan</th>
                                    <th>Status Pembayaran</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td>
                                            <strong>#<?php echo $order['id']; ?></strong>
                                        </td>
                                        <td>
                                            <div>
                                                <strong><?php echo htmlspecialchars($order['username']); ?></strong>
                                                <br>
                                                <small class="text-muted"><?php echo htmlspecialchars($order['email']); ?></small>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-secondary"><?php echo $order['item_count']; ?> item</span>
                                        </td>
                                        <td>
                                            <span class="price"><?php echo formatPrice($order['total_harga']); ?></span>
                                        </td>
                                        <td>
                                            <?php if ($order['payment_method_name']): ?>
                                                <div class="payment-method-info">
                                                    <i class="bi <?php echo $order['payment_icon']; ?>"></i>
                                                    <span><?php echo htmlspecialchars($order['payment_method_name']); ?></span>
                                                </div>
                                            <?php else: ?>
                                                <span class="text-muted">-</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php
                                            $status_class = '';
                                            $status_text = '';
                                            switch ($order['status']) {
                                                case 'pending':
                                                    $status_class = 'bg-warning';
                                                    $status_text = 'Pending';
                                                    break;
                                                case 'diproses':
                                                    $status_class = 'bg-info';
                                                    $status_text = 'Diproses';
                                                    break;
                                                case 'selesai':
                                                    $status_class = 'bg-success';
                                                    $status_text = 'Selesai';
                                                    break;
                                                case 'dibatalkan':
                                                    $status_class = 'bg-danger';
                                                    $status_text = 'Dibatalkan';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $status_class; ?>"><?php echo $status_text; ?></span>
                                        </td>
                                        <td>
                                            <?php
                                            $payment_status_class = '';
                                            $payment_status_text = '';
                                            switch ($order['payment_status']) {
                                                case 'pending':
                                                    $payment_status_class = 'bg-warning';
                                                    $payment_status_text = 'Pending';
                                                    break;
                                                case 'paid':
                                                    $payment_status_class = 'bg-success';
                                                    $payment_status_text = 'Lunas';
                                                    break;
                                                case 'failed':
                                                    $payment_status_class = 'bg-danger';
                                                    $payment_status_text = 'Gagal';
                                                    break;
                                                case 'refunded':
                                                    $payment_status_class = 'bg-info';
                                                    $payment_status_text = 'Refund';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $payment_status_class; ?> payment-status-badge"><?php echo $payment_status_text; ?></span>
                                        </td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <a href="order_detail.php?id=<?php echo $order['id']; ?>" 
                                                   class="btn btn-sm btn-outline-primary" 
                                                   data-bs-toggle="tooltip" title="Lihat Detail">
                                                    <i class="bi bi-eye"></i>
                                                </a>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-success" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#orderPaidModal" 
                                                        data-order-id="<?php echo $order['id']; ?>"
                                                        title="Tandai Sudah Dibayar"
                                                        <?php echo $order['payment_status'] === 'paid' ? 'disabled' : ''; ?>>
                                                    <i class="bi bi-check-circle"></i>
                                                </button>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-warning" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#orderProcessModal" 
                                                        data-order-id="<?php echo $order['id']; ?>"
                                                        title="Proses Pesanan"
                                                        <?php echo $order['status'] === 'diproses' || $order['status'] === 'selesai' ? 'disabled' : ''; ?>>
                                                    <i class="bi bi-gear"></i>
                                                </button>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-success" 
                                                        data-bs-toggle="modal" 
                                                        data-bs-target="#orderDoneModal" 
                                                        data-order-id="<?php echo $order['id']; ?>"
                                                        title="Selesai"
                                                        <?php echo $order['status'] === 'selesai' ? 'disabled' : ''; ?>>
                                                    <i class="bi bi-check-lg"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Modal Konfirmasi Sudah Dibayar -->
    <div class="modal fade" id="orderPaidModal" tabindex="-1" aria-labelledby="orderPaidModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="GET" action="update_order_status.php">
            <input type="hidden" name="id" id="orderPaidId">
            <input type="hidden" name="status" value="paid">
            <div class="modal-header bg-success">
              <h5 class="modal-title" id="orderPaidModalLabel"><i class="bi bi-check-circle me-2"></i>Konfirmasi Tandai Sudah Dibayar</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda yakin ingin menandai pesanan <strong>#<span id="orderPaidNum"></span></strong> sebagai <b>Sudah Dibayar</b>?</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success">Ya, Tandai Lunas</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- Modal Konfirmasi Proses Pesanan -->
    <div class="modal fade" id="orderProcessModal" tabindex="-1" aria-labelledby="orderProcessModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="GET" action="update_order_status.php">
            <input type="hidden" name="id" id="orderProcessId">
            <input type="hidden" name="status" value="diproses">
            <div class="modal-header bg-warning">
              <h5 class="modal-title" id="orderProcessModalLabel"><i class="bi bi-gear me-2"></i>Konfirmasi Proses Pesanan</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda yakin ingin memproses pesanan <strong>#<span id="orderProcessNum"></span></strong>?</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-warning">Ya, Proses</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    <!-- Modal Konfirmasi Selesai -->
    <div class="modal fade" id="orderDoneModal" tabindex="-1" aria-labelledby="orderDoneModalLabel" aria-hidden="true">
      <div class="modal-dialog">
        <div class="modal-content">
          <form method="GET" action="update_order_status.php">
            <input type="hidden" name="id" id="orderDoneId">
            <input type="hidden" name="status" value="selesai">
            <div class="modal-header bg-success">
              <h5 class="modal-title" id="orderDoneModalLabel"><i class="bi bi-check-lg me-2"></i>Konfirmasi Selesai</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
              <p>Apakah Anda yakin ingin menandai pesanan <strong>#<span id="orderDoneNum"></span></strong> sebagai <b>Selesai</b>?</p>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
              <button type="submit" class="btn btn-success">Ya, Selesai</button>
            </div>
          </form>
        </div>
      </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        var orderPaidModal = document.getElementById('orderPaidModal');
        orderPaidModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var orderId = button.getAttribute('data-order-id');
            orderPaidModal.querySelector('#orderPaidId').value = orderId;
            orderPaidModal.querySelector('#orderPaidNum').textContent = orderId;
        });
        var orderProcessModal = document.getElementById('orderProcessModal');
        orderProcessModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var orderId = button.getAttribute('data-order-id');
            orderProcessModal.querySelector('#orderProcessId').value = orderId;
            orderProcessModal.querySelector('#orderProcessNum').textContent = orderId;
        });
        var orderDoneModal = document.getElementById('orderDoneModal');
        orderDoneModal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var orderId = button.getAttribute('data-order-id');
            orderDoneModal.querySelector('#orderDoneId').value = orderId;
            orderDoneModal.querySelector('#orderDoneNum').textContent = orderId;
        });
    </script>
</body>
</html> 