<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login dan role admin
if (!isLoggedIn()) {
    redirect('../login.php');
}
if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

$user_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($user_id <= 0) {
    setAlert('error', 'ID user tidak valid!');
    redirect('users.php');
}

// Tidak boleh hapus diri sendiri
if ($user_id == $_SESSION['user_id']) {
    setAlert('error', 'Anda tidak dapat menghapus akun Anda sendiri!');
    redirect('users.php');
}

try {
    // Cek apakah user ada
    $stmt = $pdo->prepare('SELECT * FROM users WHERE id = ?');
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();
    if (!$user) {
        setAlert('error', 'User tidak ditemukan!');
        redirect('users.php');
    }
    // Hapus user
    $stmt = $pdo->prepare('DELETE FROM users WHERE id = ?');
    $result = $stmt->execute([$user_id]);
    if ($result) {
        setAlert('success', 'User berhasil dihapus!');
    } else {
        setAlert('error', 'Gagal menghapus user!');
    }
} catch (PDOException $e) {
    setAlert('error', 'Terjadi kesalahan sistem!');
}
redirect('users.php'); 