<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login dan role admin
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

// Handle form submission untuk menambah/edit metode pembayaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    
    if ($action === 'add') {
        $nama = trim($_POST['nama'] ?? '');
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        $icon = trim($_POST['icon'] ?? '');
        
        if (empty($nama)) {
            setAlert('error', 'Nama metode pembayaran harus diisi!');
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO payment_methods (nama, deskripsi, icon) VALUES (?, ?, ?)");
                $stmt->execute([$nama, $deskripsi, $icon]);
                setAlert('success', 'Metode pembayaran berhasil ditambahkan!');
            } catch (PDOException $e) {
                setAlert('error', 'Gagal menambahkan metode pembayaran!');
            }
        }
    } elseif ($action === 'edit') {
        $id = $_POST['id'] ?? '';
        $nama = trim($_POST['nama'] ?? '');
        $deskripsi = trim($_POST['deskripsi'] ?? '');
        $icon = trim($_POST['icon'] ?? '');
        $status = $_POST['status'] ?? 'aktif';
        
        if (empty($nama) || empty($id)) {
            setAlert('error', 'Data tidak lengkap!');
        } else {
            try {
                $stmt = $pdo->prepare("UPDATE payment_methods SET nama = ?, deskripsi = ?, icon = ?, status = ? WHERE id = ?");
                $stmt->execute([$nama, $deskripsi, $icon, $status, $id]);
                setAlert('success', 'Metode pembayaran berhasil diupdate!');
            } catch (PDOException $e) {
                setAlert('error', 'Gagal mengupdate metode pembayaran!');
            }
        }
    } elseif ($action === 'delete') {
        $id = $_POST['id'] ?? '';
        
        if (empty($id)) {
            setAlert('error', 'ID tidak valid!');
        } else {
            try {
                // Cek apakah metode pembayaran sedang digunakan
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM orders WHERE payment_method_id = ?");
                $stmt->execute([$id]);
                $count = $stmt->fetchColumn();
                
                if ($count > 0) {
                    setAlert('error', 'Metode pembayaran tidak dapat dihapus karena masih digunakan dalam pesanan!');
                } else {
                    $stmt = $pdo->prepare("DELETE FROM payment_methods WHERE id = ?");
                    $stmt->execute([$id]);
                    setAlert('success', 'Metode pembayaran berhasil dihapus!');
                }
            } catch (PDOException $e) {
                setAlert('error', 'Gagal menghapus metode pembayaran!');
            }
        }
    }
    
    redirect('payment_methods.php');
}

// Ambil data metode pembayaran
try {
    $stmt = $pdo->query("SELECT * FROM payment_methods ORDER BY nama");
    $payment_methods = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = 'Terjadi kesalahan sistem!';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Metode Pembayaran - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Admin Dashboard
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-speedometer2 me-1"></i>
                            Dashboard
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="payment_methods.php">
                            <i class="bi bi-credit-card me-1"></i>
                            Metode Pembayaran
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="users.php">
                            <i class="bi bi-people me-1"></i>
                            Users
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-credit-card me-2"></i>
                Manajemen Metode Pembayaran
            </h2>
            <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPaymentMethodModal">
                <i class="bi bi-plus-circle me-2"></i>
                Tambah Metode
            </button>
        </div>

        <!-- Payment Methods List -->
        <div class="card">
            <div class="card-body">
                <?php if (empty($payment_methods)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-credit-card text-muted" style="font-size: 3rem;"></i>
                        <p class="text-muted mt-3">Belum ada metode pembayaran</p>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addPaymentMethodModal">
                            Tambah Metode Pertama
                        </button>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Icon</th>
                                    <th>Nama</th>
                                    <th>Deskripsi</th>
                                    <th>Status</th>
                                    <th>Tanggal Dibuat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($payment_methods as $method): ?>
                                    <tr>
                                        <td>
                                            <i class="bi <?php echo $method['icon'] ?: 'bi-credit-card'; ?>" style="font-size: 1.5rem;"></i>
                                        </td>
                                        <td>
                                            <strong><?php echo htmlspecialchars($method['nama']); ?></strong>
                                        </td>
                                        <td>
                                            <?php echo htmlspecialchars($method['deskripsi'] ?: '-'); ?>
                                        </td>
                                        <td>
                                            <?php if ($method['status'] == 'aktif'): ?>
                                                <span class="badge bg-success">Aktif</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Nonaktif</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo date('d/m/Y H:i', strtotime($method['created_at'])); ?></td>
                                        <td>
                                            <div class="btn-group" role="group">
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-primary" 
                                                        onclick="editPaymentMethod(<?php echo htmlspecialchars(json_encode($method)); ?>)"
                                                        data-bs-toggle="tooltip" title="Edit">
                                                    <i class="bi bi-pencil"></i>
                                                </button>
                                                <button type="button" 
                                                        class="btn btn-sm btn-outline-danger" 
                                                        onclick="deletePaymentMethod(<?php echo $method['id']; ?>, '<?php echo htmlspecialchars($method['nama']); ?>')"
                                                        data-bs-toggle="tooltip" title="Hapus">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Add Payment Method Modal -->
    <div class="modal fade" id="addPaymentMethodModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="add">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="bi bi-plus-circle me-2"></i>
                            Tambah Metode Pembayaran
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="nama" class="form-label">Nama Metode Pembayaran *</label>
                            <input type="text" class="form-control" id="nama" name="nama" required>
                        </div>
                        <div class="mb-3">
                            <label for="deskripsi" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="icon" class="form-label">Icon (Bootstrap Icons)</label>
                            <input type="text" class="form-control" id="icon" name="icon" placeholder="Contoh: bi-credit-card">
                            <small class="text-muted">Lihat daftar icon di <a href="https://icons.getbootstrap.com/" target="_blank">Bootstrap Icons</a></small>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Simpan</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Payment Method Modal -->
    <div class="modal fade" id="editPaymentMethodModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="edit">
                    <input type="hidden" name="id" id="edit_id">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="bi bi-pencil me-2"></i>
                            Edit Metode Pembayaran
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label for="edit_nama" class="form-label">Nama Metode Pembayaran *</label>
                            <input type="text" class="form-control" id="edit_nama" name="nama" required>
                        </div>
                        <div class="mb-3">
                            <label for="edit_deskripsi" class="form-label">Deskripsi</label>
                            <textarea class="form-control" id="edit_deskripsi" name="deskripsi" rows="3"></textarea>
                        </div>
                        <div class="mb-3">
                            <label for="edit_icon" class="form-label">Icon (Bootstrap Icons)</label>
                            <input type="text" class="form-control" id="edit_icon" name="icon" placeholder="Contoh: bi-credit-card">
                        </div>
                        <div class="mb-3">
                            <label for="edit_status" class="form-label">Status</label>
                            <select class="form-select" id="edit_status" name="status">
                                <option value="aktif">Aktif</option>
                                <option value="nonaktif">Nonaktif</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-primary">Update</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Delete Payment Method Modal -->
    <div class="modal fade" id="deletePaymentMethodModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" id="delete_id">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="bi bi-exclamation-triangle me-2"></i>
                            Konfirmasi Hapus
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>Apakah Anda yakin ingin menghapus metode pembayaran <strong id="delete_name"></strong>?</p>
                        <p class="text-danger">Tindakan ini tidak dapat dibatalkan!</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-danger">Hapus</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        function editPaymentMethod(method) {
            document.getElementById('edit_id').value = method.id;
            document.getElementById('edit_nama').value = method.nama;
            document.getElementById('edit_deskripsi').value = method.deskripsi || '';
            document.getElementById('edit_icon').value = method.icon || '';
            document.getElementById('edit_status').value = method.status;
            
            new bootstrap.Modal(document.getElementById('editPaymentMethodModal')).show();
        }
        
        function deletePaymentMethod(id, name) {
            document.getElementById('delete_id').value = id;
            document.getElementById('delete_name').textContent = name;
            
            new bootstrap.Modal(document.getElementById('deletePaymentMethodModal')).show();
        }
    </script>
</body>
</html> 