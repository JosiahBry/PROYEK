<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

if (!isLoggedIn()) {
    redirect('../login.php');
}
if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

$order_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if ($order_id <= 0) {
    die('ID pesanan tidak valid.');
}

try {
    $stmt = $pdo->prepare('SELECT o.*, u.username, u.email, pm.nama as payment_method_name, pm.icon as payment_icon FROM orders o JOIN users u ON o.user_id = u.id LEFT JOIN payment_methods pm ON o.payment_method_id = pm.id WHERE o.id = ?');
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();
    if (!$order) {
        die('Pesanan tidak ditemukan.');
    }
    $stmt = $pdo->prepare('SELECT oi.*, m.nama FROM order_items oi JOIN menu m ON oi.menu_id = m.id WHERE oi.order_id = ?');
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll();
} catch (PDOException $e) {
    die('Terjadi kesalahan sistem!');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Pesanan #<?php echo $order_id; ?> - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Admin Dashboard
            </a>
        </div>
    </nav>
    <div class="container mt-4">
        <a href="orders.php" class="btn btn-secondary mb-3"><i class="bi bi-arrow-left"></i> Kembali ke Daftar Pesanan</a>
        <div class="card mb-4">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">Detail Pesanan #<?php echo $order['id']; ?></h5>
            </div>
            <div class="card-body">
                <dl class="row">
                    <dt class="col-sm-3">ID Pesanan</dt>
                    <dd class="col-sm-9">#<?php echo $order['id']; ?></dd>
                    <dt class="col-sm-3">Customer</dt>
                    <dd class="col-sm-9"><?php echo htmlspecialchars($order['username']); ?> (<?php echo htmlspecialchars($order['email']); ?>)</dd>
                    <dt class="col-sm-3">Total Harga</dt>
                    <dd class="col-sm-9"><?php echo formatPrice($order['total_harga']); ?></dd>
                    <dt class="col-sm-3">Metode Pembayaran</dt>
                    <dd class="col-sm-9">
                        <?php if ($order['payment_method_name']): ?>
                            <i class="bi <?php echo $order['payment_icon']; ?> me-1"></i>
                            <?php echo htmlspecialchars($order['payment_method_name']); ?>
                        <?php else: ?>
                            <span class="text-muted">-</span>
                        <?php endif; ?>
                    </dd>
                    <dt class="col-sm-3">Status Pesanan</dt>
                    <dd class="col-sm-9">
                        <span class="badge bg-<?php echo $order['status'] === 'pending' ? 'warning' : ($order['status'] === 'diproses' ? 'info' : ($order['status'] === 'selesai' ? 'success' : 'danger')); ?>">
                            <?php echo ucfirst($order['status']); ?>
                        </span>
                    </dd>
                    <dt class="col-sm-3">Status Pembayaran</dt>
                    <dd class="col-sm-9">
                        <span class="badge bg-<?php echo $order['payment_status'] === 'pending' ? 'warning' : ($order['payment_status'] === 'paid' ? 'success' : ($order['payment_status'] === 'failed' ? 'danger' : 'info')); ?>">
                            <?php echo $order['payment_status'] === 'paid' ? 'Lunas' : ucfirst($order['payment_status']); ?>
                        </span>
                    </dd>
                    <dt class="col-sm-3">Tanggal</dt>
                    <dd class="col-sm-9"><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></dd>
                </dl>
                <hr>
                <h6>Item Pesanan:</h6>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Menu</th>
                                <th>Qty</th>
                                <th>Harga Satuan</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($item['nama']); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td><?php echo formatPrice($item['harga_satuan']); ?></td>
                                    <td><?php echo formatPrice($item['subtotal']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html> 