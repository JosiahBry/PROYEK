<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login dan role admin
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (!isAdmin()) {
    redirect('../user/dashboard.php');
}

$order_id = $_GET['id'] ?? null;
$status = $_GET['status'] ?? null;

// Validasi input
if (!$order_id || !$status) {
    setAlert('error', 'Parameter tidak lengkap!');
    redirect('orders.php');
}

// Validasi status
$allowed_statuses = ['pending', 'diproses', 'selesai', 'dibatalkan', 'paid', 'failed', 'refunded'];
if (!in_array($status, $allowed_statuses)) {
    setAlert('error', 'Status tidak valid!');
    redirect('orders.php');
}

try {
    // Tentukan field yang akan diupdate
    if (in_array($status, ['paid', 'failed', 'refunded'])) {
        // Update payment status
        $stmt = $pdo->prepare("UPDATE orders SET payment_status = ? WHERE id = ?");
        $result = $stmt->execute([$status, $order_id]);
        $message = 'Status pembayaran berhasil diupdate';
    } else {
        // Update order status
        $stmt = $pdo->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $result = $stmt->execute([$status, $order_id]);
        $message = 'Status pesanan berhasil diupdate';
    }
    
    if ($result) {
        setAlert('success', $message);
    } else {
        setAlert('error', 'Gagal update status!');
    }
} catch (PDOException $e) {
    setAlert('error', 'Terjadi kesalahan sistem!');
}

redirect('orders.php');
?> 