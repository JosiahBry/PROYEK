# Website Menu Restoran - Restoran Lezat

Website menu restoran lengkap dengan sistem login, manajemen menu, dan pemesanan online. Dibangun menggunakan PHP, MySQL, Bootstrap 5, dan JavaScript.

## 🚀 Fitur Utama

### 🔐 Sistem Autentikasi
- **Login & Register** untuk admin dan konsumen
- **Role-based access control** (Admin & Customer)
- **Session management** dengan proteksi halaman
- **Password hashing** untuk keamanan

### 👤 Dashboard Berbeda
- **Admin Dashboard**: Manajemen menu, pesanan, dan users
- **Customer Dashboard**: Lihat menu, pesan, dan riwayat pesanan

### 🍽️ Manajemen Menu
- **CRUD Menu** (Create, Read, Update, Delete)
- **Upload gambar** menu dengan preview
- **Kategori** makanan dan minuman
- **Status** tersedia/tidak tersedia

### 🛒 Sistem Keranjang Belanja
- **Keranjang belanja** dengan localStorage
- **Quantity control** untuk setiap menu
- **Checkout** dan konfirmasi pesanan
- **Riwayat pesanan** untuk customer dan admin

### 💳 Sistem Checkout & Pembayaran
- **Halaman checkout yang user-friendly**
- **Pilihan metode pembayaran:**
  - Tunai (bayar di tempat)
  - Transfer Bank
  - E-Wallet (OVO, DANA, GoPay)
  - QRIS
  - Kartu Debit/Kredit
- **Informasi pengiriman lengkap**
- **Status pembayaran real-time**
- **Instruksi pembayaran otomatis**

### 📋 Manajemen Pesanan
- **Customer:**
  - Lihat riwayat pesanan
  - Detail pesanan lengkap
  - Status pesanan dan pembayaran
  - Instruksi pembayaran
  - Cetak struk

- **Admin:**
  - Dashboard pesanan
  - Update status pesanan
  - Update status pembayaran
  - Filter berdasarkan status
  - Manajemen metode pembayaran

### 👥 Sistem User
- Registrasi dan login
- Role-based access (Admin/Customer)
- Profile management

## 🛠 Teknologi yang Digunakan

- **Frontend**: HTML5, CSS3, Bootstrap 5, JavaScript
- **Backend**: PHP 7.4+
- **Database**: MySQL
- **Server**: XAMPP
- **Icons**: Bootstrap Icons
- **Fonts**: Google Fonts (Poppins)

## 📁 Struktur Project

```
restoran-website/
├── config/
│   └── database.php          # Konfigurasi database
├── includes/
│   └── functions.php         # Fungsi helper
├── assets/
│   ├── css/
│   │   └── style.css         # Custom CSS
│   ├── js/
│   │   └── script.js         # JavaScript
│   └── images/
│       └── menu/             # Gambar menu
├── admin/
│   ├── dashboard.php         # Dashboard admin
│   ├── menu.php              # Manajemen menu
│   ├── menu_add.php          # Tambah menu
│   ├── menu_edit.php         # Edit menu
│   ├── menu_delete.php       # Hapus menu
│   ├── orders.php            # Manajemen pesanan
│   ├── update_order_status.php # Update status pesanan
│   └── users.php             # Manajemen users
├── user/
│   ├── dashboard.php         # Dashboard customer
│   ├── menu.php              # Lihat menu
│   ├── orders.php            # Riwayat pesanan
│   ├── cart.php              # Keranjang belanja
│   └── checkout.php          # Checkout
├── database/
│   └── restoran_db.sql       # Struktur database
├── index.php                 # Halaman utama
├── login.php                 # Halaman login
├── register.php              # Halaman register
├── logout.php                # Logout
└── README.md                 # Dokumentasi
```

## 🗄 Struktur Database

### Tabel `users`
- `id` (Primary Key)
- `username` (Unique)
- `email` (Unique)
- `password` (Hashed)
- `role` (admin/customer)
- `created_at`, `updated_at`

### Tabel `menu`
- `id` (Primary Key)
- `nama`
- `deskripsi`
- `harga`
- `kategori` (makanan/minuman)
- `gambar`
- `status` (tersedia/tidak_tersedia)
- `created_at`, `updated_at`

### Tabel `orders`
- `id` (Primary Key)
- `user_id` (Foreign Key)
- `total_harga`
- `status` (pending/diproses/selesai/dibatalkan)
- `catatan`
- `created_at`, `updated_at`

### Tabel `order_items`
- `id` (Primary Key)
- `order_id` (Foreign Key)
- `menu_id` (Foreign Key)
- `quantity`
- `harga_satuan`
- `subtotal`

### Tabel `carts`
- `id` (Primary Key)
- `user_id` (Foreign Key)
- `created_at`, `updated_at`

### Tabel `cart_items`
- `id` (Primary Key)
- `cart_id` (Foreign Key)
- `menu_id` (Foreign Key)
- `quantity`
- `harga_satuan`
- `subtotal`

### Tabel `payment_methods`
- `id` (Primary Key)
- `nama`
- `created_at`, `updated_at`

## 🚀 Cara Install & Setup

### 1. Persiapan
- Install XAMPP (Apache + MySQL + PHP)
- Pastikan PHP 7.4+ terinstall
- Aktifkan Apache dan MySQL di XAMPP

### 2. Setup Database
1. Buka phpMyAdmin: `http://localhost/phpmyadmin`
2. Buat database baru: `restoran_db`
3. Import file `database/restoran_db.sql`

### 3. Setup Project
1. Copy semua file ke folder: `C:/xampp/htdocs/restoran-website/`
2. Pastikan folder `assets/images/menu/` memiliki permission write
3. Buka website: `http://localhost/restoran-website/`

### 4. Akun Default
**Admin:**
- Email: `admin@restoran.com`
- Password: `password`

**Customer:**
- Register akun baru melalui halaman register

## 🎨 Fitur UI/UX

### Design Modern
- **Responsive design** untuk semua device
- **Bootstrap 5** untuk komponen UI
- **Custom CSS** dengan variabel CSS
- **Smooth animations** dan hover effects
- **Bootstrap Icons** untuk iconography

### User Experience
- **Intuitive navigation** dengan breadcrumbs
- **Real-time cart** dengan localStorage
- **Search & filter** menu
- **Form validation** client & server side
- **Alert messages** untuk feedback
- **Loading states** dan error handling

## 🔧 Fitur Admin

### Dashboard Admin
- **Statistik real-time**: total menu, pesanan hari ini, pendapatan, customer
- **Quick actions**: tambah menu, lihat pesanan, kelola users
- **Recent orders**: pesanan terbaru dengan status

### Manajemen Menu
- **Tambah menu** dengan upload gambar
- **Edit menu** dengan preview gambar
- **Hapus menu** dengan konfirmasi
- **Status menu** tersedia/tidak tersedia

### Manajemen Pesanan
- **Lihat semua pesanan** dari customer
- **Update status** pesanan via AJAX
- **Filter pesanan** berdasarkan status
- **Detail pesanan** lengkap

## 👥 Fitur Customer

### Dashboard Customer
- **Statistik personal**: total pesanan, pengeluaran
- **Menu favorit** berdasarkan riwayat pesanan
- **Pesanan terbaru** dengan status

### Pemesanan
- **Browse menu** dengan search & filter
- **Add to cart** dengan quantity control
- **Cart summary** real-time
- **Checkout** dengan catatan pesanan

### Riwayat Pesanan
- **Lihat semua pesanan** pribadi
- **Filter pesanan** berdasarkan status
- **Detail pesanan** lengkap

## 🔒 Keamanan

### Authentication & Authorization
- **Password hashing** dengan `password_hash()`
- **Session management** yang aman
- **Role-based access control**
- **CSRF protection** pada form

### Input Validation
- **Server-side validation** untuk semua input
- **Client-side validation** dengan JavaScript
- **SQL injection prevention** dengan prepared statements
- **XSS prevention** dengan `htmlspecialchars()`

### File Upload Security
- **File type validation** (JPG, PNG, GIF only)
- **File size limit** (2MB)
- **Unique filename** generation
- **Secure upload directory**

## 📱 Responsive Design

### Breakpoints
- **Mobile**: < 768px
- **Tablet**: 768px - 991px
- **Desktop**: > 992px

### Features
- **Mobile-first** approach
- **Flexible grid** system
- **Touch-friendly** buttons
- **Optimized images** untuk mobile

## 🚀 Performance

### Optimization
- **Minified CSS/JS** (Bootstrap CDN)
- **Optimized images** dengan proper sizing
- **Efficient database queries** dengan indexing
- **Caching** dengan localStorage untuk cart

### Best Practices
- **Semantic HTML** structure
- **Accessibility** features
- **SEO-friendly** URLs
- **Clean code** dengan proper comments

## 🐛 Troubleshooting

### Common Issues
1. **Database connection error**: Cek konfigurasi di `config/database.php`
2. **Upload gambar gagal**: Cek permission folder `assets/images/menu/`
3. **Session tidak bekerja**: Pastikan session_start() dipanggil
4. **CSS/JS tidak load**: Cek path file di browser developer tools

### Debug Mode
- Aktifkan error reporting di PHP untuk development
- Gunakan browser developer tools untuk debugging
- Cek error log Apache di XAMPP

## 📝 Changelog

### Version 1.0.0
- ✅ Sistem login & register
- ✅ Dashboard admin & customer
- ✅ Manajemen menu CRUD
- ✅ Sistem pemesanan
- ✅ Manajemen pesanan
- ✅ Responsive design
- ✅ Security features

## 🤝 Contributing

1. Fork project ini
2. Buat feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push ke branch (`git push origin feature/AmazingFeature`)
5. Buat Pull Request

## 📄 License

Project ini dibuat untuk tujuan edukasi dan portfolio. Silakan gunakan dan modifikasi sesuai kebutuhan.

## 👨‍💻 Author

**Restoran Lezat Team**
- Website: [restoranlezat.com](https://restoranlezat.com)
- Email: info@restoranlezat.com

---

**Note**: Pastikan untuk mengubah konfigurasi database dan email sesuai dengan environment Anda sebelum deploy ke production. 