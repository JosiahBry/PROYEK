<?php
header('Location: login.php');
exit;

// Halaman Login Baru (placeholder)
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Konsumen - Restoran Lezat</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container" style="margin-top: 100px; text-align: center;">
        <h1>Login Konsumen</h1>
        <p>Silakan login menggunakan akun konsumen Anda.</p>
        <a href="login.php" class="btn btn-primary">Login Sekarang</a>
    </div>
</body>
</html> 