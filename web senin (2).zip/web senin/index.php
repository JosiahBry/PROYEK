<?php
require_once 'includes/functions.php';

// Redirect jika sudah login
if (isLoggedIn()) {
    if (isAdmin()) {
        redirect('admin/dashboard.php');
    } else {
        redirect('user/dashboard.php');
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Restoran Lezat - Menu Terbaik</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="index.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Restoran Lezat
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#menu">Menu</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">Tentang</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Kontak</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-outline-primary ms-2" href="login-baru.php">Login</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link btn btn-primary ms-2" href="register-baru.php">Register</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h1>Selamat Datang di Restoran Lezat</h1>
                    <p class="lead">Nikmati hidangan lezat dengan cita rasa autentik dan pelayanan terbaik</p>
                    <div class="d-flex gap-3">
                        <a href="daftar.php" class="btn btn-light btn-lg">Daftar Sekarang</a>
                        <a href="#menu" class="btn btn-outline-light btn-lg">Lihat Menu</a>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <img src="assets/images/hero-food.png" alt="Makanan Lezat" class="img-fluid" style="max-height: 400px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Menu Section -->
    <section id="menu" class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="display-4 fw-bold">Menu Favorit</h2>
                <p class="lead text-muted">Pilihan menu terbaik dengan kualitas premium</p>
            </div>
            
            <div class="row">
                <div class="col-md-4 mb-4">
                    <div class="card menu-card h-100">
                        <img src="assets/images/menu/nasi_goreng.jpg" class="card-img-top" alt="Nasi Goreng">
                        <div class="card-body">
                            <h5 class="card-title">Nasi Goreng</h5>
                            <p class="card-text">Nasi goreng dengan telur, ayam, dan sayuran segar</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price">Rp 25.000</span>
                                <span class="category-badge">Makanan</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card menu-card h-100">
                        <img src="assets/images/menu/ayam_goreng.jpg" class="card-img-top" alt="Ayam Goreng">
                        <div class="card-body">
                            <h5 class="card-title">Ayam Goreng</h5>
                            <p class="card-text">Ayam goreng crispy dengan sambal terasi</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price">Rp 35.000</span>
                                <span class="category-badge">Makanan</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4 mb-4">
                    <div class="card menu-card h-100">
                        <img src="assets/images/menu/es_teh.jpg" class="card-img-top" alt="Es Teh Manis">
                        <div class="card-body">
                            <h5 class="card-title">Es Teh Manis</h5>
                            <p class="card-text">Es teh manis segar untuk menemani hidangan Anda</p>
                            <div class="d-flex justify-content-between align-items-center">
                                <span class="price">Rp 5.000</span>
                                <span class="category-badge">Minuman</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="text-center mt-4">
                <a href="register-baru.php" class="btn btn-primary btn-lg">Lihat Semua Menu</a>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section id="about" class="py-5 bg-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <h2 class="display-5 fw-bold mb-4">Tentang Restoran Lezat</h2>
                    <p class="lead mb-4">Restoran Lezat adalah destinasi kuliner terbaik yang menyajikan hidangan lezat dengan cita rasa autentik Indonesia.</p>
                    <div class="row">
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-3">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Bahan Berkualitas</span>
                            </div>
                            <div class="d-flex align-items-center mb-3">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Chef Profesional</span>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="d-flex align-items-center mb-3">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Pelayanan Cepat</span>
                            </div>
                            <div class="d-flex align-items-center mb-3">
                                <i class="bi bi-check-circle-fill text-success me-2"></i>
                                <span>Harga Terjangkau</span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 text-center">
                    <img src="assets/images/restaurant.jpg" alt="Restoran" class="img-fluid rounded">
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="py-5">
        <div class="container">
            <div class="text-center mb-5">
                <h2 class="display-4 fw-bold">Hubungi Kami</h2>
                <p class="lead text-muted">Kami siap melayani pesanan Anda</p>
            </div>
            
            <div class="row">
                <div class="col-md-4 text-center mb-4">
                    <div class="p-4">
                        <i class="bi bi-geo-alt-fill text-primary" style="font-size: 3rem;"></i>
                        <h5 class="mt-3">Lokasi</h5>
                        <p class="text-muted">Jl. Restoran No. 123, Jakarta Selatan</p>
                    </div>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="p-4">
                        <i class="bi bi-telephone-fill text-primary" style="font-size: 3rem;"></i>
                        <h5 class="mt-3">Telepon</h5>
                        <p class="text-muted">+62 21 1234 5678</p>
                    </div>
                </div>
                <div class="col-md-4 text-center mb-4">
                    <div class="p-4">
                        <i class="bi bi-envelope-fill text-primary" style="font-size: 3rem;"></i>
                        <h5 class="mt-3">Email</h5>
                        <p class="text-muted">info@restoranlezat.com</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h5>Restoran Lezat</h5>
                    <p>Menyajikan hidangan lezat dengan cita rasa autentik Indonesia.</p>
                </div>
                <div class="col-md-6 text-md-end">
                    <h5>Jam Operasional</h5>
                    <p>Senin - Minggu: 08:00 - 22:00</p>
                </div>
            </div>
            <hr class="my-4">
            <div class="text-center">
                <p>&copy; 2024 Restoran Lezat. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/script.js"></script>
</body>
</html> 