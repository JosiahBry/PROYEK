<?php
header('Location: register.php');
exit;

// Halaman Register Baru (placeholder)
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register Konsumen - Restoran Lezat</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container" style="margin-top: 100px; text-align: center;">
        <h1>Register Konsumen</h1>
        <p>Silakan daftar sebagai konsumen untuk mulai memesan.</p>
        <a href="register.php" class="btn btn-primary">Register Sekarang</a>
    </div>
</body>
</html> 