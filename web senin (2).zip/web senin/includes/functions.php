<?php
session_start();

// Fungsi untuk mengecek apakah user sudah login
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Fungsi untuk mengecek role user
function getUserRole() {
    return $_SESSION['role'] ?? null;
}

// Fungsi untuk mengecek apakah user adalah admin
function isAdmin() {
    return getUserRole() === 'admin';
}

// Fungsi untuk mengecek apakah user adalah konsumen
function isCustomer() {
    return getUserRole() === 'customer';
}

// Fungsi untuk redirect
function redirect($location) {
    header("Location: $location");
    exit();
}

// Fungsi untuk menampilkan pesan alert
function showAlert($message, $type = 'info') {
    $_SESSION['alert'] = [
        'message' => $message,
        'type' => $type
    ];
}

// Fungsi untuk menampilkan dan menghapus alert
function getAlert() {
    if (isset($_SESSION['alert'])) {
        $alert = $_SESSION['alert'];
        unset($_SESSION['alert']);
        return $alert;
    }
    return null;
}

// Fungsi untuk upload gambar
function uploadImage($file, $target_dir = 'assets/images/menu/') {
    if (!file_exists($target_dir)) {
        mkdir($target_dir, 0777, true);
    }
    
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_extensions = ['jpg', 'jpeg', 'png', 'gif'];
    
    if (!in_array($file_extension, $allowed_extensions)) {
        return false;
    }
    
    $new_filename = uniqid() . '.' . $file_extension;
    $target_file = $target_dir . $new_filename;
    
    if (move_uploaded_file($file['tmp_name'], $target_file)) {
        return $new_filename;
    }
    
    return false;
}

// Fungsi untuk format harga
function formatPrice($price) {
    return 'Rp ' . number_format($price, 0, ',', '.');
}

// Fungsi untuk mendapatkan nama user
function getUserName() {
    return $_SESSION['username'] ?? 'User';
}

// Alias agar kompatibel dengan pemanggilan setAlert()
function setAlert($type, $message) {
    showAlert($message, $type);
}
?> 