# Database Setup untuk Sistem Restoran

## Struktur Database

Database ini terdiri dari 4 tabel utama:

### 1. Tabel `users`
- **id**: Primary key auto increment
- **username**: Username unik (max 50 karakter)
- **email**: Email unik (max 100 karakter)
- **password**: Password yang di-hash (255 karakter)
- **role**: Role user ('admin' atau 'customer')
- **created_at**: Timestamp pembuatan akun
- **updated_at**: Timestamp update terakhir

### 2. Tabel `menu`
- **id**: Primary key auto increment
- **nama**: Nama menu (max 100 karakter)
- **deskripsi**: Deskripsi menu (TEXT)
- **harga**: Harga menu (DECIMAL 10,2)
- **kategori**: Kategori ('makanan' atau 'minuman')
- **gambar**: Nama file gambar menu
- **status**: Status ketersediaan ('tersedia' atau 'tidak_tersedia')
- **created_at**: Timestamp pembuatan menu
- **updated_at**: Timestamp update terakhir

### 3. Tabel `orders`
- **id**: Primary key auto increment
- **user_id**: Foreign key ke tabel users
- **total_harga**: Total harga pesanan (DECIMAL 10,2)
- **status**: Status pesanan ('pending', 'diproses', 'selesai', 'dibatalkan')
- **catatan**: Catatan tambahan untuk pesanan
- **created_at**: Timestamp pembuatan pesanan
- **updated_at**: Timestamp update terakhir

### 4. Tabel `order_items`
- **id**: Primary key auto increment
- **order_id**: Foreign key ke tabel orders
- **menu_id**: Foreign key ke tabel menu
- **quantity**: Jumlah item
- **harga_satuan**: Harga per item (DECIMAL 10,2)
- **subtotal**: Total harga item (quantity × harga_satuan)

## Cara Setup Database

### Opsi 1: Menggunakan Setup Script (Direkomendasikan)
1. Pastikan XAMPP sudah berjalan (Apache & MySQL)
2. Buka browser dan akses: `http://localhost/web%20senin/database/setup_database.php`
3. Script akan otomatis membuat database dan tabel yang diperlukan
4. Data sample akan otomatis ditambahkan

### Opsi 2: Menggunakan SQL File
1. Buka phpMyAdmin: `http://localhost/phpmyadmin`
2. Buat database baru dengan nama `restoran_db`
3. Import file `restoran_db.sql`
4. Database akan otomatis ter-setup dengan data sample

## Akun Default

Setelah setup, tersedia akun default berikut:

### Admin Account
- **Email**: admin@restoran.com
- **Password**: admin123
- **Role**: Admin

### Customer Accounts
- **Email**: customer@example.com
- **Password**: customer123
- **Role**: Customer

- **Email**: john@example.com
- **Password**: customer123
- **Role**: Customer

- **Email**: jane@example.com
- **Password**: customer123
- **Role**: Customer

## Konfigurasi Database

File konfigurasi database berada di `config/database.php`:

```php
$host = 'localhost';
$dbname = 'restoran_db';
$username = 'root';
$password = '';
```

Pastikan konfigurasi sesuai dengan pengaturan MySQL/XAMPP Anda.

## Keamanan

1. **Password Hashing**: Semua password di-hash menggunakan `password_hash()` dengan algoritma bcrypt
2. **SQL Injection Protection**: Menggunakan prepared statements untuk semua query database
3. **Session Management**: Menggunakan PHP sessions untuk manajemen login
4. **Input Validation**: Validasi input user di semua form

## Troubleshooting

### Error "Connection failed"
- Pastikan XAMPP MySQL service berjalan
- Cek konfigurasi database di `config/database.php`
- Pastikan database `restoran_db` sudah dibuat

### Error "Table doesn't exist"
- Jalankan setup script atau import SQL file
- Pastikan semua tabel sudah dibuat dengan benar

### Login tidak berfungsi
- Pastikan password di database sudah di-hash
- Cek apakah session sudah dimulai di `includes/functions.php`
- Pastikan role user sudah benar ('admin' atau 'customer')

## Backup Database

Untuk backup database:
1. Buka phpMyAdmin
2. Pilih database `restoran_db`
3. Klik tab "Export"
4. Pilih format SQL
5. Download file backup

## Restore Database

Untuk restore database:
1. Buka phpMyAdmin
2. Buat database baru atau pilih database yang ada
3. Klik tab "Import"
4. Upload file SQL backup
5. Klik "Go" untuk restore 