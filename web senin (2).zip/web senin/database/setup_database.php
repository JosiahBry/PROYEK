<?php
// Script untuk setup database restoran
require_once __DIR__ . '/../config/database.php';

echo "<h2>Setup Database Restoran</h2>";

try {
    // Buat database jika belum ada
    $pdo->exec("CREATE DATABASE IF NOT EXISTS restoran_db");
    $pdo->exec("USE restoran_db");
    
    // Buat tabel users
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) UNIQUE NOT NULL,
            email VARCHAR(100) UNIQUE NOT NULL,
            password VARCHAR(255) NOT NULL,
            role ENUM('admin', 'customer') DEFAULT 'customer',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");
    
    // Buat tabel menu
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS menu (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nama VARCHAR(100) NOT NULL,
            deskripsi TEXT,
            harga DECIMAL(10,2) NOT NULL,
            kategori ENUM('makanan', 'minuman') NOT NULL,
            gambar VARCHAR(255),
            status ENUM('tersedia', 'tidak_tersedia') DEFAULT 'tersedia',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        )
    ");
    
    // Buat tabel orders
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS orders (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            total_harga DECIMAL(10,2) NOT NULL,
            status ENUM('pending', 'diproses', 'selesai', 'dibatalkan') DEFAULT 'pending',
            catatan TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    ");
    
    // Buat tabel order_items
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS order_items (
            id INT AUTO_INCREMENT PRIMARY KEY,
            order_id INT NOT NULL,
            menu_id INT NOT NULL,
            quantity INT NOT NULL,
            harga_satuan DECIMAL(10,2) NOT NULL,
            subtotal DECIMAL(10,2) NOT NULL,
            FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
            FOREIGN KEY (menu_id) REFERENCES menu(id) ON DELETE CASCADE
        )
    ");
    
    // Buat tabel payment_methods jika belum ada
    $sql = "CREATE TABLE IF NOT EXISTS payment_methods (
        id INT AUTO_INCREMENT PRIMARY KEY,
        nama VARCHAR(100) NOT NULL,
        deskripsi TEXT,
        icon VARCHAR(100),
        status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    $pdo->exec($sql);
    echo "<p>✓ Tabel payment_methods berhasil dibuat</p>";
    
    // Cek apakah kolom payment_method_id sudah ada di tabel orders
    $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'payment_method_id'");
    if ($stmt->rowCount() == 0) {
        // Tambah kolom payment_method_id
        $pdo->exec("ALTER TABLE orders ADD COLUMN payment_method_id INT");
        $pdo->exec("ALTER TABLE orders ADD FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id) ON DELETE SET NULL");
        echo "<p>✓ Kolom payment_method_id berhasil ditambahkan ke tabel orders</p>";
    } else {
        echo "<p>✓ Kolom payment_method_id sudah ada</p>";
    }
    
    // Cek apakah kolom payment_status sudah ada di tabel orders
    $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'payment_status'");
    if ($stmt->rowCount() == 0) {
        // Tambah kolom payment_status
        $pdo->exec("ALTER TABLE orders ADD COLUMN payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending'");
        echo "<p>✓ Kolom payment_status berhasil ditambahkan ke tabel orders</p>";
    } else {
        echo "<p>✓ Kolom payment_status sudah ada</p>";
    }
    
    // Cek apakah kolom alamat_pengiriman sudah ada di tabel orders
    $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'alamat_pengiriman'");
    if ($stmt->rowCount() == 0) {
        // Tambah kolom alamat_pengiriman
        $pdo->exec("ALTER TABLE orders ADD COLUMN alamat_pengiriman TEXT");
        echo "<p>✓ Kolom alamat_pengiriman berhasil ditambahkan ke tabel orders</p>";
    } else {
        echo "<p>✓ Kolom alamat_pengiriman sudah ada</p>";
    }
    
    // Cek apakah kolom nomor_telepon sudah ada di tabel orders
    $stmt = $pdo->query("SHOW COLUMNS FROM orders LIKE 'nomor_telepon'");
    if ($stmt->rowCount() == 0) {
        // Tambah kolom nomor_telepon
        $pdo->exec("ALTER TABLE orders ADD COLUMN nomor_telepon VARCHAR(20)");
        echo "<p>✓ Kolom nomor_telepon berhasil ditambahkan ke tabel orders</p>";
    } else {
        echo "<p>✓ Kolom nomor_telepon sudah ada</p>";
    }
    
    // Insert data metode pembayaran jika belum ada
    $stmt = $pdo->query("SELECT COUNT(*) FROM payment_methods");
    $count = $stmt->fetchColumn();
    
    if ($count == 0) {
        $payment_methods = [
            ['Tunai', 'Bayar dengan uang tunai saat pengambilan', 'bi-cash-coin'],
            ['Transfer Bank', 'Transfer ke rekening bank kami', 'bi-bank'],
            ['E-Wallet', 'Bayar dengan e-wallet (OVO, DANA, GoPay)', 'bi-phone'],
            ['QRIS', 'Scan QRIS untuk pembayaran', 'bi-qr-code'],
            ['Kartu Debit/Kredit', 'Bayar dengan kartu debit atau kredit', 'bi-credit-card']
        ];
        
        $stmt = $pdo->prepare("INSERT INTO payment_methods (nama, deskripsi, icon) VALUES (?, ?, ?)");
        foreach ($payment_methods as $method) {
            $stmt->execute($method);
        }
        echo "<p>✓ Data metode pembayaran berhasil ditambahkan</p>";
    } else {
        echo "<p>✓ Data metode pembayaran sudah ada</p>";
    }
    
    // Cek apakah sudah ada data admin
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'admin'");
    $stmt->execute();
    $adminCount = $stmt->fetchColumn();
    
    if ($adminCount == 0) {
        // Insert data admin default
        $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password, role) VALUES 
            ('admin', 'admin@restoran.com', ?, 'admin')
        ");
        $stmt->execute([$adminPassword]);
        echo "✓ Admin account created<br>";
    }
    
    // Cek apakah sudah ada data customer
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM users WHERE role = 'customer'");
    $stmt->execute();
    $customerCount = $stmt->fetchColumn();
    
    if ($customerCount == 0) {
        // Insert data customer default
        $customerPassword = password_hash('customer123', PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("
            INSERT INTO users (username, email, password, role) VALUES 
            ('customer', 'customer@example.com', ?, 'customer'),
            ('john_doe', 'john@example.com', ?, 'customer'),
            ('jane_smith', 'jane@example.com', ?, 'customer')
        ");
        $stmt->execute([$customerPassword, $customerPassword, $customerPassword]);
        echo "✓ Customer accounts created<br>";
    }
    
    // Cek apakah sudah ada data menu
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM menu");
    $stmt->execute();
    $menuCount = $stmt->fetchColumn();
    
    if ($menuCount == 0) {
        // Insert data menu contoh
        $stmt = $pdo->prepare("
            INSERT INTO menu (nama, deskripsi, harga, kategori, gambar) VALUES 
            ('Nasi Goreng', 'Nasi goreng dengan telur, ayam, dan sayuran segar', 25000, 'makanan', 'nasi_goreng.jpg'),
            ('Mie Goreng', 'Mie goreng dengan bumbu special dan topping lengkap', 22000, 'makanan', 'mie_goreng.jpg'),
            ('Ayam Goreng', 'Ayam goreng crispy dengan sambal terasi', 35000, 'makanan', 'ayam_goreng.jpg'),
            ('Sate Ayam', 'Sate ayam dengan bumbu kacang dan lontong', 30000, 'makanan', 'sate_ayam.jpg'),
            ('Gado-gado', 'Sayuran segar dengan bumbu kacang', 20000, 'makanan', 'gado_gado.jpg'),
            ('Es Teh Manis', 'Es teh manis segar', 5000, 'minuman', 'es_teh.jpg'),
            ('Es Jeruk', 'Es jeruk peras segar', 8000, 'minuman', 'es_jeruk.jpg'),
            ('Kopi Hitam', 'Kopi hitam pahit', 12000, 'minuman', 'kopi_hitam.jpg'),
            ('Es Campur', 'Es campur dengan berbagai topping', 15000, 'minuman', 'es_campur.jpg'),
            ('Jus Alpukat', 'Jus alpukat segar', 18000, 'minuman', 'jus_alpukat.jpg')
        ");
        $stmt->execute();
        echo "✓ Sample menu items created<br>";
    }
    
    echo "<h3>Setup Database Selesai!</h3>";
    echo "<p>Database telah berhasil dikonfigurasi dengan fitur pembayaran.</p>";
    echo "<p><a href='../index.php'>Kembali ke Beranda</a></p>";
    
} catch (PDOException $e) {
    echo "<p style='color: red;'>Error: " . $e->getMessage() . "</p>";
}
?> 