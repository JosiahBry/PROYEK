-- Database: restoran_db
-- Struktur database untuk website menu restoran

CREATE DATABASE IF NOT EXISTS restoran_db;
USE restoran_db;

-- Tabel users untuk menyimpan data pengguna
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel menu untuk menyimpan data menu makanan dan minuman
CREATE TABLE menu (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    deskripsi TEXT,
    harga DECIMAL(10,2) NOT NULL,
    kategori ENUM('makanan', 'minuman') NOT NULL,
    gambar VARCHAR(255),
    status ENUM('tersedia', 'tidak_tersedia') DEFAULT 'tersedia',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabel payment_methods untuk menyimpan metode pembayaran yang tersedia
CREATE TABLE payment_methods (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    deskripsi TEXT,
    icon VARCHAR(100),
    status ENUM('aktif', 'nonaktif') DEFAULT 'aktif',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel orders untuk menyimpan data pesanan
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_harga DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'diproses', 'selesai', 'dibatalkan') DEFAULT 'pending',
    payment_method_id INT,
    payment_status ENUM('pending', 'paid', 'failed', 'refunded') DEFAULT 'pending',
    catatan TEXT,
    alamat_pengiriman TEXT,
    nomor_telepon VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (payment_method_id) REFERENCES payment_methods(id) ON DELETE SET NULL
);

-- Tabel order_items untuk menyimpan detail item pesanan
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    menu_id INT NOT NULL,
    quantity INT NOT NULL,
    harga_satuan DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_id) REFERENCES menu(id) ON DELETE CASCADE
);

-- Tabel carts untuk menyimpan keranjang belanja user (belum checkout)
CREATE TABLE carts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    status ENUM('active', 'checked_out') DEFAULT 'active',
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Tabel cart_items untuk menyimpan item dalam keranjang
CREATE TABLE cart_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cart_id INT NOT NULL,
    menu_id INT NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (cart_id) REFERENCES carts(id) ON DELETE CASCADE,
    FOREIGN KEY (menu_id) REFERENCES menu(id) ON DELETE CASCADE,
    UNIQUE KEY unique_cart_menu (cart_id, menu_id)
);

-- Insert data admin default (password: admin123)
INSERT INTO users (username, email, password, role) VALUES 
('admin', 'admin@restoran.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Insert data customer default (password: customer123)
INSERT INTO users (username, email, password, role) VALUES 
('customer', 'customer@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer'),
('john_doe', 'john@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer'),
('jane_smith', 'jane@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer');

-- Insert data metode pembayaran
INSERT INTO payment_methods (nama, deskripsi, icon) VALUES 
('Tunai', 'Bayar dengan uang tunai saat pengambilan', 'bi-cash-coin'),
('Transfer Bank', 'Transfer ke rekening bank kami', 'bi-bank'),
('E-Wallet', 'Bayar dengan e-wallet (OVO, DANA, GoPay)', 'bi-phone'),
('QRIS', 'Scan QRIS untuk pembayaran', 'bi-qr-code'),
('Kartu Debit/Kredit', 'Bayar dengan kartu debit atau kredit', 'bi-credit-card');

-- Insert data menu contoh
INSERT INTO menu (nama, deskripsi, harga, kategori, gambar) VALUES 
('Nasi Goreng', 'Nasi goreng dengan telur, ayam, dan sayuran segar', 25000, 'makanan', 'nasi_goreng.jpg'),
('Mie Goreng', 'Mie goreng dengan bumbu special dan topping lengkap', 22000, 'makanan', 'mie_goreng.jpg'),
('Ayam Goreng', 'Ayam goreng crispy dengan sambal terasi', 35000, 'makanan', 'ayam_goreng.jpg'),
('Sate Ayam', 'Sate ayam dengan bumbu kacang dan lontong', 30000, 'makanan', 'sate_ayam.jpg'),
('Gado-gado', 'Sayuran segar dengan bumbu kacang', 20000, 'makanan', 'gado_gado.jpg'),
('Soto Ayam', 'Soto ayam dengan kuah kaldu yang gurih', 28000, 'makanan', 'soto_ayam.jpg'),
('Rendang Daging', 'Rendang daging sapi dengan bumbu rempah', 45000, 'makanan', 'rendang_daging.jpg'),
('Es Teh Manis', 'Es teh manis segar', 5000, 'minuman', 'es_teh.jpg'),
('Es Jeruk', 'Es jeruk peras segar', 8000, 'minuman', 'es_jeruk.jpg'),
('Kopi Hitam', 'Kopi hitam pahit', 12000, 'minuman', 'kopi_hitam.jpg'),
('Es Campur', 'Es campur dengan berbagai topping', 15000, 'minuman', 'es_campur.jpg'),
('Jus Alpukat', 'Jus alpukat segar', 18000, 'minuman', 'jus_alpukat.jpg'),
('Es Cendol', 'Es cendol dengan santan dan gula merah', 10000, 'minuman', 'es_cendol.jpg'),
('Wedang Jahe', 'Wedang jahe hangat untuk kesehatan', 8000, 'minuman', 'wedang_jahe.jpg'); 