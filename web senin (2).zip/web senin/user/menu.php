<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

// Ambil cart aktif dan item jika user login
$cart_quantities = [];
if (isLoggedIn() && !isAdmin()) {
    $user_id = $_SESSION['user_id'];
    $stmt = $pdo->prepare("SELECT c.id as cart_id FROM carts c WHERE c.user_id = ? AND c.status = 'active' LIMIT 1");
    $stmt->execute([$user_id]);
    $cart = $stmt->fetch();
    if ($cart) {
        $stmt = $pdo->prepare("SELECT menu_id, quantity FROM cart_items WHERE cart_id = ?");
        $stmt->execute([$cart['cart_id']]);
        foreach ($stmt->fetchAll() as $row) {
            $cart_quantities[$row['menu_id']] = $row['quantity'];
        }
    }
}

// Filter dan search
$category_filter = $_GET['category'] ?? 'all';
$search = $_GET['search'] ?? '';

// Ambil data menu
try {
    $where_conditions = ["status = 'tersedia'"];
    $params = [];
    
    if ($category_filter != 'all') {
        $where_conditions[] = "kategori = ?";
        $params[] = $category_filter;
    }
    
    if (!empty($search)) {
        $where_conditions[] = "(nama LIKE ? OR deskripsi LIKE ?)";
        $params[] = "%$search%";
        $params[] = "%$search%";
    }
    
    $where_clause = implode(' AND ', $where_conditions);
    $sql = "SELECT * FROM menu WHERE $where_clause ORDER BY kategori, nama";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $menu_list = $stmt->fetchAll();
    
    // Group menu by category
    $menu_by_category = [];
    foreach ($menu_list as $menu) {
        $menu_by_category[$menu['kategori']][] = $menu;
    }
    
} catch (PDOException $e) {
    $error = 'Terjadi kesalahan sistem!';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu - Restoran Lezat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <script>window.isUserLoggedIn = true;</script>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Restoran Lezat
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-house me-1"></i>
                            Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan Saya
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                Menu Restoran
            </h2>
            <a href="cart.php" class="btn btn-primary">
                <i class="bi bi-cart3 me-2"></i>
                Lihat Keranjang
            </a>
        </div>

        <!-- Search and Filter -->
        <div class="row mb-4">
            <div class="col-md-8">
                <form method="GET" action="" class="d-flex gap-2">
                    <input type="text" class="form-control" id="searchInput" name="search" 
                           placeholder="Cari menu..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit" class="btn btn-outline-primary">
                        <i class="bi bi-search"></i>
                    </button>
                </form>
            </div>
            <div class="col-md-4">
                <select class="form-select" id="categoryFilter" name="category" onchange="this.form.submit()">
                    <option value="all" <?php echo $category_filter == 'all' ? 'selected' : ''; ?>>Semua Kategori</option>
                    <option value="makanan" <?php echo $category_filter == 'makanan' ? 'selected' : ''; ?>>Makanan</option>
                    <option value="minuman" <?php echo $category_filter == 'minuman' ? 'selected' : ''; ?>>Minuman</option>
                </select>
            </div>
        </div>

        <!-- Menu Content -->
        <div class="row">
            <div class="col-lg-9">
                <?php if (empty($menu_list)): ?>
                    <div class="text-center py-5">
                        <i class="bi bi-search text-muted" style="font-size: 3rem;"></i>
                        <h4 class="text-muted mt-3">Menu tidak ditemukan</h4>
                        <p class="text-muted">Coba ubah filter atau kata kunci pencarian Anda</p>
                        <a href="menu.php" class="btn btn-primary">Lihat Semua Menu</a>
                    </div>
                <?php else: ?>
                    <?php foreach ($menu_by_category as $category => $menus): ?>
                        <div class="mb-5">
                            <h3 class="mb-4">
                                <i class="bi bi-<?php echo $category == 'makanan' ? 'egg-fried' : 'cup-straw'; ?> me-2"></i>
                                <?php echo ucfirst($category); ?>
                            </h3>
                            <div class="row">
                                <?php foreach ($menus as $menu): ?>
                                    <div class="col-md-6 col-lg-4 mb-4">
                                        <div class="card menu-card h-100" 
                                             data-menu-id="<?php echo $menu['id']; ?>" 
                                             data-category="<?php echo $menu['kategori']; ?>"
                                             data-price="<?php echo $menu['harga']; ?>">
                                            <img src="../assets/images/menu/<?php echo $menu['gambar'] ?: 'default.jpg'; ?>" 
                                                 class="card-img-top" alt="<?php echo htmlspecialchars($menu['nama']); ?>">
                                            <div class="card-body">
                                                <h5 class="card-title"><?php echo htmlspecialchars($menu['nama']); ?></h5>
                                                <p class="card-text"><?php echo htmlspecialchars($menu['deskripsi']); ?></p>
                                                <div class="d-flex justify-content-between align-items-center mb-3">
                                                    <span class="price"><?php echo formatPrice($menu['harga']); ?></span>
                                                    <span class="category-badge"><?php echo ucfirst($menu['kategori']); ?></span>
                                                </div>
                                                
                                                <!-- Quantity Control -->
                                                <div class="quantity-control">
                                                    <button type="button" class="quantity-btn" 
                                                            data-menu-id="<?php echo $menu['id']; ?>" 
                                                            data-change="decrease">-</button>
                                                    <input type="number" class="quantity-input" 
                                                           id="quantity-<?php echo $menu['id']; ?>" 
                                                           data-menu-id="<?php echo $menu['id']; ?>" 
                                                           value="<?php echo isset($cart_quantities[$menu['id']]) ? $cart_quantities[$menu['id']] : 0; ?>" min="0" max="99">
                                                    <button type="button" class="quantity-btn" 
                                                            data-menu-id="<?php echo $menu['id']; ?>" 
                                                            data-change="increase">+</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Cart Summary Sidebar -->
            <div class="col-lg-3">
                <div class="cart-summary">
                    <div id="cart-summary">
                        <?php
                        // Ambil cart aktif dan item
                        $cart_data = [];
                        $cart_total = 0;
                        if (isLoggedIn() && !isAdmin()) {
                            $user_id = $_SESSION['user_id'];
                            $stmt = $pdo->prepare("SELECT id FROM carts WHERE user_id = ? AND status = 'active' LIMIT 1");
                            $stmt->execute([$user_id]);
                            $cart = $stmt->fetch();
                            if ($cart) {
                                $stmt = $pdo->prepare("
                                    SELECT ci.menu_id, m.nama, m.harga, m.gambar, m.deskripsi, m.kategori, SUM(ci.quantity) as quantity
                                    FROM cart_items ci
                                    JOIN menu m ON ci.menu_id = m.id
                                    WHERE ci.cart_id = ?
                                    GROUP BY ci.menu_id, m.nama, m.harga, m.gambar, m.deskripsi, m.kategori
                                    ORDER BY m.nama
                                ");
                                $stmt->execute([$cart['id']]);
                                $cart_data = $stmt->fetchAll();
                                $cart_total = 0;
                                foreach ($cart_data as &$item) {
                                    $item['subtotal'] = $item['harga'] * $item['quantity'];
                                    $cart_total += $item['subtotal'];
                                }
                            }
                        }

                        if (!empty($cart_data)) {
                            // Gabungkan item dengan menu_id yang sama (jika masih ada duplikat dari data lama)
                            $merged_cart = [];
                            foreach ($cart_data as $item) {
                                $id = $item['menu_id'];
                                if (!isset($merged_cart[$id])) {
                                    $merged_cart[$id] = $item;
                                } else {
                                    $merged_cart[$id]['quantity'] += $item['quantity'];
                                    $merged_cart[$id]['subtotal'] += $item['harga'] * $item['quantity'];
                                }
                            }
                            $cart_data = array_values($merged_cart);
                            // Recalculate cart_total after merging
                            $cart_total = 0;
                            foreach ($cart_data as $item) {
                                $cart_total += $item['subtotal'];
                            }
                        }
                        ?>
                        <h5 class="mb-3">Keranjang Belanja</h5>
                        <?php if (empty($cart_data)): ?>
                            <p class="text-muted">Keranjang kosong</p>
                        <?php else: ?>
                            <?php foreach ($cart_data as $item): ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <small class="fw-bold"><?php echo htmlspecialchars($item['nama']); ?></small><br>
                                        <small class="text-muted"><?php echo $item['quantity']; ?>x @ <?php echo formatPrice($item['harga']); ?></small>
                                    </div>
                                    <small class="fw-bold"><?php echo formatPrice($item['subtotal']); ?></small>
                                </div>
                            <?php endforeach; ?>
                            <hr>
                            <div class="d-flex justify-content-between align-items-center">
                                <strong>Total:</strong>
                                <strong class="text-primary"><?php echo formatPrice($cart_total); ?></strong>
                            </div>
                            <a href="checkout.php" class="btn btn-primary w-100 mt-3">Checkout</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html> 