<?php
require_once '../includes/functions.php';
require_once '../config/database.php';
header('Content-Type: application/json');

if (!isLoggedIn() || isAdmin()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$user_id = $_SESSION['user_id'];
$menu_id = isset($_POST['menu_id']) ? intval($_POST['menu_id']) : 0;
$quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

if ($menu_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'Menu tidak valid']);
    exit;
}

try {
    // Cari cart aktif
    $stmt = $pdo->prepare("SELECT * FROM carts WHERE user_id = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$user_id]);
    $cart = $stmt->fetch();

    if (!$cart) {
        // Buat cart baru
        $stmt = $pdo->prepare("INSERT INTO carts (user_id, status) VALUES (?, 'active')");
        $stmt->execute([$user_id]);
        $cart_id = $pdo->lastInsertId();
    } else {
        $cart_id = $cart['id'];
    }

    // Cek apakah item sudah ada di cart
    $stmt = $pdo->prepare("SELECT * FROM cart_items WHERE cart_id = ? AND menu_id = ?");
    $stmt->execute([$cart_id, $menu_id]);
    $item = $stmt->fetch();

    if ($quantity > 0) {
        if ($item) {
            // Update quantity
            $stmt = $pdo->prepare("UPDATE cart_items SET quantity = ? WHERE id = ?");
            $stmt->execute([$quantity, $item['id']]);
        } else {
            // Insert item baru
            $stmt = $pdo->prepare("INSERT INTO cart_items (cart_id, menu_id, quantity) VALUES (?, ?, ?)");
            $stmt->execute([$cart_id, $menu_id, $quantity]);
        }
    } else {
        if ($item) {
            // Hapus item dari cart
            $stmt = $pdo->prepare("DELETE FROM cart_items WHERE id = ?");
            $stmt->execute([$item['id']]);
        }
    }

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'Gagal update keranjang']);
} 