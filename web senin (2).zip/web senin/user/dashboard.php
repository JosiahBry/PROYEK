<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

// Ambil data user
$user_id = $_SESSION['user_id'];

// Ambil statistik user
try {
    // Total pesanan user
    $stmt = $pdo->prepare("SELECT COUNT(*) as total_orders FROM orders WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_orders = $stmt->fetch()['total_orders'];
    
    // Total pengeluaran
    $stmt = $pdo->prepare("SELECT COALESCE(SUM(total_harga), 0) as total_spent FROM orders WHERE user_id = ? AND status != 'dibatalkan'");
    $stmt->execute([$user_id]);
    $total_spent = $stmt->fetch()['total_spent'];
    
    // Pesanan terbaru user
    $stmt = $pdo->prepare("
        SELECT o.*, COUNT(oi.id) as item_count 
        FROM orders o 
        LEFT JOIN order_items oi ON o.id = oi.order_id 
        WHERE o.user_id = ? 
        GROUP BY o.id 
        ORDER BY o.created_at DESC 
        LIMIT 5
    ");
    $stmt->execute([$user_id]);
    $recent_orders = $stmt->fetchAll();
    
    // Menu favorit (berdasarkan pesanan)
    $stmt = $pdo->prepare("
        SELECT m.nama, m.gambar, m.harga, COUNT(oi.id) as order_count 
        FROM order_items oi 
        JOIN menu m ON oi.menu_id = m.id 
        JOIN orders o ON oi.order_id = o.id 
        WHERE o.user_id = ? 
        GROUP BY m.id 
        ORDER BY order_count DESC 
        LIMIT 3
    ");
    $stmt->execute([$user_id]);
    $favorite_menu = $stmt->fetchAll();
    
} catch (PDOException $e) {
    $error = 'Terjadi kesalahan sistem!';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Restoran Lezat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Restoran Lezat
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">
                            <i class="bi bi-house me-1"></i>
                            Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan Saya
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Welcome Section -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card bg-primary text-white">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h4 class="mb-2">Selamat datang, <?php echo getUserName(); ?>!</h4>
                                <p class="mb-0">Nikmati hidangan lezat dari Restoran Lezat. Pesan sekarang dan nikmati pengalaman kuliner terbaik.</p>
                            </div>
                            <div class="col-md-4 text-md-end">
                                <a href="menu.php" class="btn btn-light">
                                    Lihat Menu
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="row mb-4">
            <div class="col-md-6 mb-3">
                <div class="dashboard-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3><?php echo $total_orders; ?></h3>
                            <p>Total Pesanan</p>
                        </div>
                        <i class="bi bi-cart" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
            <div class="col-md-6 mb-3">
                <div class="dashboard-card">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h3><?php echo formatPrice($total_spent); ?></h3>
                            <p>Total Pengeluaran</p>
                        </div>
                        <i class="bi bi-currency-dollar" style="font-size: 2rem;"></i>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-lightning me-2"></i>
                            Menu Cepat
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-12 col-md-4 mb-2">
                                <a href="menu.php" class="btn btn-primary w-100">
                                    Lihat Menu
                                </a>
                            </div>
                            <div class="col-12 col-md-4 mb-2">
                                <a href="orders.php" class="btn btn-success w-100">
                                    Pesanan Saya
                                </a>
                            </div>
                            <div class="col-12 col-md-4 mb-2">
                                <a href="cart.php" class="btn btn-warning w-100">
                                    Keranjang
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu Favorit -->
        <?php if (!empty($favorite_menu)): ?>
        <div class="row mb-4">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h5 class="mb-0">
                            <i class="bi bi-heart me-2"></i>
                            Menu Favorit Anda
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php foreach ($favorite_menu as $menu): ?>
                                <div class="col-md-4 mb-3">
                                    <div class="card menu-card h-100">
                                        <img src="../assets/images/menu/<?php echo $menu['gambar']; ?>" 
                                             class="card-img-top" alt="<?php echo htmlspecialchars($menu['nama']); ?>">
                                        <div class="card-body">
                                            <h6 class="card-title"><?php echo htmlspecialchars($menu['nama']); ?></h6>
                                            <p class="card-text">Dipesan <?php echo $menu['order_count']; ?> kali</p>
                                            <div class="d-flex justify-content-between align-items-center">
                                                <span class="price"><?php echo formatPrice($menu['harga']); ?></span>
                                                <a href="menu.php" class="btn btn-sm btn-primary">Pesan Lagi</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Recent Orders -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h5 class="mb-0">
                            <i class="bi bi-clock-history me-2"></i>
                            Pesanan Terbaru
                        </h5>
                        <a href="orders.php" class="btn btn-sm btn-primary">Lihat Semua</a>
                    </div>
                    <div class="card-body">
                        <?php if (empty($recent_orders)): ?>
                            <div class="text-center py-4">
                                <i class="bi bi-cart-x text-muted" style="font-size: 3rem;"></i>
                                <p class="text-muted mt-3">Belum ada pesanan</p>
                                <a href="menu.php" class="btn btn-primary">Mulai Pesan</a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Item</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Tanggal</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($recent_orders as $order): ?>
                                            <tr>
                                                <td>#<?php echo $order['id']; ?></td>
                                                <td><?php echo $order['item_count']; ?> item</td>
                                                <td><?php echo formatPrice($order['total_harga']); ?></td>
                                                <td>
                                                    <span class="status-badge status-<?php echo $order['status']; ?>">
                                                        <?php echo ucfirst($order['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html> 