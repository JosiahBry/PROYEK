<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

$user_id = $_SESSION['user_id'];

// Ambil cart aktif
$cart_data = [];
$cart_total = 0;
$stmt = $pdo->prepare("SELECT * FROM carts WHERE user_id = ? AND status = 'active' LIMIT 1");
$stmt->execute([$user_id]);
$cart = $stmt->fetch();
if ($cart) {
    $stmt = $pdo->prepare("
        SELECT ci.*, m.nama, m.harga, m.gambar, m.deskripsi, m.kategori
        FROM cart_items ci
        JOIN menu m ON ci.menu_id = m.id
        WHERE ci.cart_id = ?
    ");
    $stmt->execute([$cart['id']]);
    $cart_data = $stmt->fetchAll();
    foreach ($cart_data as &$item) {
        $item['subtotal'] = $item['harga'] * $item['quantity'];
        $cart_total += $item['subtotal'];
    }
}

// Ambil semua pesanan user
$stmt = $pdo->prepare("
    SELECT o.*, pm.nama as payment_method_name, pm.icon as payment_icon
    FROM orders o
    LEFT JOIN payment_methods pm ON o.payment_method_id = pm.id
    WHERE o.user_id = ?
    ORDER BY o.created_at DESC
");
$stmt->execute([$user_id]);
$orders = $stmt->fetchAll();

// Jika ada parameter order_id, tampilkan detail pesanan tertentu
$selected_order = null;
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    $stmt = $pdo->prepare("
        SELECT o.*, pm.nama as payment_method_name, pm.icon as payment_icon, pm.deskripsi as payment_description
        FROM orders o
        LEFT JOIN payment_methods pm ON o.payment_method_id = pm.id
        WHERE o.id = ? AND o.user_id = ?
    ");
    $stmt->execute([$order_id, $user_id]);
    $selected_order = $stmt->fetch();
    
    if ($selected_order) {
        // Ambil detail items pesanan
        $stmt = $pdo->prepare("
            SELECT oi.*, m.nama, m.gambar, m.deskripsi, m.kategori
            FROM order_items oi
            JOIN menu m ON oi.menu_id = m.id
            WHERE oi.order_id = ?
        ");
        $stmt->execute([$order_id]);
        $order_items = $stmt->fetchAll();
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pesanan Saya - Restoran Lezat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .order-card {
            transition: transform 0.2s ease;
        }
        
        .order-card:hover {
            transform: translateY(-2px);
        }
        
        .status-badge {
            font-size: 0.8rem;
        }
        
        .payment-status-badge {
            font-size: 0.8rem;
        }
        
        .order-detail-item {
            border-left: 3px solid #0d6efd;
            padding-left: 15px;
            margin-bottom: 15px;
        }
        
        .payment-info {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border-radius: 10px;
            padding: 20px;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Restoran Lezat
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-house me-1"></i>
                            Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan Saya
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-cart me-2"></i>
                Pesanan Saya
            </h2>
            <?php if ($selected_order): ?>
                <a href="orders.php" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-2"></i>
                    Kembali ke Daftar Pesanan
                </a>
            <?php else: ?>
                <a href="menu.php" class="btn btn-primary">
                    <i class="bi bi-plus-circle me-2"></i>
                    Pesan Lagi
                </a>
            <?php endif; ?>
        </div>

        <!-- Keranjang Aktif (Belum Checkout) -->
        <?php if (!empty($cart_data) && !$selected_order): ?>
            <div class="card mb-4">
                <div class="card-header bg-warning">
                    <strong>Keranjang Belanja (Belum Checkout)</strong>
                </div>
                <div class="card-body">
                    <?php foreach ($cart_data as $item): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <small class="fw-bold"><?php echo htmlspecialchars($item['nama']); ?></small>
                                <br>
                                <small class="text-muted"><?php echo $item['quantity']; ?>x @ <?php echo formatPrice($item['harga']); ?></small>
                            </div>
                            <small class="fw-bold"><?php echo formatPrice($item['subtotal']); ?></small>
                        </div>
                    <?php endforeach; ?>
                    <hr>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <strong>Total:</strong>
                        <strong class="text-primary fs-5"><?php echo formatPrice($cart_total); ?></strong>
                    </div>
                    <a href="checkout.php" class="btn btn-primary w-100">
                        <i class="bi bi-credit-card me-2"></i>
                        Checkout Sekarang
                    </a>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($selected_order): ?>
            <!-- Order Detail -->
            <div class="row">
                <div class="col-lg-8">
                    <!-- Order Items -->
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-list-ul me-2"></i>
                                Detail Pesanan #<?php echo $selected_order['id']; ?>
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($order_items as $item): ?>
                                <div class="order-detail-item">
                                    <div class="row align-items-center">
                                        <div class="col-md-2">
                                            <img src="../assets/images/menu/<?php echo $item['gambar'] ?: 'default.jpg'; ?>" 
                                                 alt="<?php echo htmlspecialchars($item['nama']); ?>" 
                                                 class="img-fluid rounded">
                                        </div>
                                        <div class="col-md-6">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($item['nama']); ?></h6>
                                            <small class="text-muted"><?php echo htmlspecialchars($item['deskripsi']); ?></small>
                                            <br>
                                            <span class="category-badge"><?php echo ucfirst($item['kategori']); ?></span>
                                        </div>
                                        <div class="col-md-2 text-center">
                                            <span class="text-muted"><?php echo $item['quantity']; ?>x</span>
                                        </div>
                                        <div class="col-md-2 text-end">
                                            <span class="price"><?php echo formatPrice($item['subtotal']); ?></span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                            
                            <hr>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <strong>Total:</strong>
                                <strong class="text-primary fs-5"><?php echo formatPrice($selected_order['total_harga']); ?></strong>
                            </div>
                        </div>
                    </div>

                    <!-- Order Information -->
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-info-circle me-2"></i>
                                Informasi Pesanan
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Status Pesanan:</strong></p>
                                    <?php
                                    $status_class = '';
                                    $status_text = '';
                                    switch ($selected_order['status']) {
                                        case 'pending':
                                            $status_class = 'bg-warning';
                                            $status_text = 'Menunggu Konfirmasi';
                                            break;
                                        case 'diproses':
                                            $status_class = 'bg-info';
                                            $status_text = 'Sedang Diproses';
                                            break;
                                        case 'selesai':
                                            $status_class = 'bg-success';
                                            $status_text = 'Selesai';
                                            break;
                                        case 'dibatalkan':
                                            $status_class = 'bg-danger';
                                            $status_text = 'Dibatalkan';
                                            break;
                                    }
                                    ?>
                                    <span class="badge <?php echo $status_class; ?> status-badge"><?php echo $status_text; ?></span>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Status Pembayaran:</strong></p>
                                    <?php
                                    $payment_status_class = '';
                                    $payment_status_text = '';
                                    switch ($selected_order['payment_status']) {
                                        case 'pending':
                                            $payment_status_class = 'bg-warning';
                                            $payment_status_text = 'Menunggu Pembayaran';
                                            break;
                                        case 'paid':
                                            $payment_status_class = 'bg-success';
                                            $payment_status_text = 'Sudah Dibayar';
                                            break;
                                        case 'failed':
                                            $payment_status_class = 'bg-danger';
                                            $payment_status_text = 'Gagal';
                                            break;
                                        case 'refunded':
                                            $payment_status_class = 'bg-info';
                                            $payment_status_text = 'Dikembalikan';
                                            break;
                                    }
                                    ?>
                                    <span class="badge <?php echo $payment_status_class; ?> payment-status-badge"><?php echo $payment_status_text; ?></span>
                                </div>
                            </div>
                            
                            <hr>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <p><strong>Tanggal Pesanan:</strong><br>
                                    <small class="text-muted"><?php echo date('d/m/Y H:i', strtotime($selected_order['created_at'])); ?></small></p>
                                </div>
                                <div class="col-md-6">
                                    <p><strong>Nomor Telepon:</strong><br>
                                    <small class="text-muted"><?php echo htmlspecialchars($selected_order['nomor_telepon']); ?></small></p>
                                </div>
                            </div>
                            
                            <?php if ($selected_order['catatan']): ?>
                                <div class="mb-3">
                                    <p><strong>Catatan:</strong><br>
                                    <small class="text-muted"><?php echo nl2br(htmlspecialchars($selected_order['catatan'])); ?></small></p>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- Payment Information -->
                <div class="col-lg-4">
                    <div class="payment-info mb-4">
                        <h5 class="mb-3">
                            <i class="bi bi-credit-card me-2"></i>
                            Informasi Pembayaran
                        </h5>
                        
                        <?php if ($selected_order['payment_method_name']): ?>
                            <div class="mb-3">
                                <p class="mb-1"><strong>Metode Pembayaran:</strong></p>
                                <div class="d-flex align-items-center">
                                    <i class="bi <?php echo $selected_order['payment_icon']; ?> me-2" style="font-size: 1.5rem;"></i>
                                    <span><?php echo htmlspecialchars($selected_order['payment_method_name']); ?></span>
                                </div>
                                <small class="text-light"><?php echo htmlspecialchars($selected_order['payment_description']); ?></small>
                            </div>
                        <?php endif; ?>
                        
                        <div class="mb-3">
                            <p class="mb-1"><strong>Total Pembayaran:</strong></p>
                            <h4 class="mb-0"><?php echo formatPrice($selected_order['total_harga']); ?></h4>
                        </div>
                        
                        <?php if ($selected_order['payment_status'] === 'pending'): ?>
                            <div class="alert alert-warning mb-0">
                                <small>
                                    <i class="bi bi-exclamation-triangle me-1"></i>
                                    Silakan lakukan pembayaran sesuai metode yang dipilih
                                </small>
                            </div>
                        <?php elseif ($selected_order['payment_status'] === 'paid'): ?>
                            <div class="alert alert-success mb-0">
                                <small>
                                    <i class="bi bi-check-circle me-1"></i>
                                    Pembayaran telah diterima
                                </small>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Action Buttons -->
                    <div class="card">
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <?php if ($selected_order['payment_status'] === 'pending'): ?>
                                    <button class="btn btn-primary" onclick="showPaymentInstructions()">
                                        <i class="bi bi-info-circle me-2"></i>
                                        Lihat Instruksi Pembayaran
                                    </button>
                                <?php endif; ?>
                                
                                <a href="menu.php" class="btn btn-outline-primary">
                                    <i class="bi bi-plus-circle me-2"></i>
                                    Pesan Lagi
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <!-- Orders List -->
            <?php if (empty($orders)): ?>
                <div class="text-center py-5">
                    <i class="bi bi-cart-x text-muted" style="font-size: 4rem;"></i>
                    <h4 class="text-muted mt-3">Belum Ada Pesanan</h4>
                    <p class="text-muted">Anda belum memiliki pesanan</p>
                    <a href="menu.php" class="btn btn-primary">
                        <i class="bi bi-list-ul me-2"></i>
                        Lihat Menu
                    </a>
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach ($orders as $order): ?>
                        <div class="col-lg-6 col-xl-4 mb-4">
                            <div class="card order-card h-100">
                                <div class="card-header">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <h6 class="mb-0">Pesanan #<?php echo $order['id']; ?></h6>
                                        <small class="text-muted"><?php echo date('d/m/Y', strtotime($order['created_at'])); ?></small>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="mb-3">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span class="fw-bold">Total:</span>
                                            <span class="price"><?php echo formatPrice($order['total_harga']); ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <span>Status:</span>
                                            <?php
                                            $status_class = '';
                                            $status_text = '';
                                            switch ($order['status']) {
                                                case 'pending':
                                                    $status_class = 'bg-warning';
                                                    $status_text = 'Menunggu';
                                                    break;
                                                case 'diproses':
                                                    $status_class = 'bg-info';
                                                    $status_text = 'Diproses';
                                                    break;
                                                case 'selesai':
                                                    $status_class = 'bg-success';
                                                    $status_text = 'Selesai';
                                                    break;
                                                case 'dibatalkan':
                                                    $status_class = 'bg-danger';
                                                    $status_text = 'Dibatalkan';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $status_class; ?> status-badge"><?php echo $status_text; ?></span>
                                        </div>
                                        
                                        <div class="d-flex justify-content-between align-items-center">
                                            <span>Pembayaran:</span>
                                            <?php
                                            $payment_status_class = '';
                                            $payment_status_text = '';
                                            switch ($order['payment_status']) {
                                                case 'pending':
                                                    $payment_status_class = 'bg-warning';
                                                    $payment_status_text = 'Pending';
                                                    break;
                                                case 'paid':
                                                    $payment_status_class = 'bg-success';
                                                    $payment_status_text = 'Lunas';
                                                    break;
                                                case 'failed':
                                                    $payment_status_class = 'bg-danger';
                                                    $payment_status_text = 'Gagal';
                                                    break;
                                                case 'refunded':
                                                    $payment_status_class = 'bg-info';
                                                    $payment_status_text = 'Refund';
                                                    break;
                                            }
                                            ?>
                                            <span class="badge <?php echo $payment_status_class; ?> payment-status-badge"><?php echo $payment_status_text; ?></span>
                                        </div>
                                    </div>
                                    
                                    <?php if ($order['payment_method_name']): ?>
                                        <div class="mb-3">
                                            <small class="text-muted">
                                                <i class="bi <?php echo $order['payment_icon']; ?> me-1"></i>
                                                <?php echo htmlspecialchars($order['payment_method_name']); ?>
                                            </small>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Payment Instructions Modal -->
    <div class="modal fade" id="paymentModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">
                        <i class="bi bi-credit-card me-2"></i>
                        Instruksi Pembayaran
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div id="paymentInstructions">
                        <!-- Instructions will be loaded here -->
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        function showPaymentInstructions() {
            const paymentMethod = '<?php echo $selected_order ? $selected_order['payment_method_name'] : ''; ?>';
            let instructions = '';
            
            switch (paymentMethod) {
                case 'Tunai':
                    instructions = `
                        <div class="alert alert-info">
                            <h6>Pembayaran Tunai</h6>
                            <p>Bayar dengan uang tunai saat pengambilan pesanan di restoran.</p>
                            <ul>
                                <li>Siapkan uang pas</li>
                                <li>Tunjukkan nomor pesanan #<?php echo $selected_order['id']; ?></li>
                                <li>Pesanan akan diproses setelah pembayaran</li>
                            </ul>
                        </div>
                    `;
                    break;
                case 'Transfer Bank':
                    instructions = `
                        <div class="alert alert-info">
                            <h6>Transfer Bank</h6>
                            <p>Transfer ke rekening berikut:</p>
                            <ul>
                                <li><strong>Bank:</strong> BCA</li>
                                <li><strong>No. Rekening:</strong> 1234567890</li>
                                <li><strong>Atas Nama:</strong> Restoran Lezat</li>
                                <li><strong>Jumlah:</strong> <?php echo formatPrice($selected_order['total_harga']); ?></li>
                            </ul>
                            <p class="mb-0"><strong>Catatan:</strong> Simpan bukti transfer dan kirim ke admin</p>
                        </div>
                    `;
                    break;
                case 'E-Wallet':
                    instructions = `
                        <div class="alert alert-info">
                            <h6>E-Wallet</h6>
                            <p>Bayar menggunakan e-wallet favorit Anda:</p>
                            <ul>
                                <li>OVO: 081234567890</li>
                                <li>DANA: 081234567890</li>
                                <li>GoPay: 081234567890</li>
                            </ul>
                            <p class="mb-0"><strong>Jumlah:</strong> <?php echo formatPrice($selected_order['total_harga']); ?></p>
                        </div>
                    `;
                    break;
                case 'QRIS':
                    instructions = `
                        <div class="alert alert-info">
                            <h6>QRIS</h6>
                            <p>Scan QRIS code berikut dengan aplikasi e-wallet atau mobile banking Anda:</p>
                            <div class="text-center">
                                <div class="bg-light p-3 d-inline-block rounded">
                                    <i class="bi bi-qr-code" style="font-size: 5rem;"></i>
                                </div>
                            </div>
                            <p class="mb-0 mt-3"><strong>Jumlah:</strong> <?php echo formatPrice($selected_order['total_harga']); ?></p>
                        </div>
                    `;
                    break;
                case 'Kartu Debit/Kredit':
                    instructions = `
                        <div class="alert alert-info">
                            <h6>Kartu Debit/Kredit</h6>
                            <p>Bayar menggunakan kartu debit atau kredit di restoran:</p>
                            <ul>
                                <li>Kartu Visa</li>
                                <li>Kartu Mastercard</li>
                                <li>Kartu JCB</li>
                            </ul>
                            <p class="mb-0"><strong>Jumlah:</strong> <?php echo formatPrice($selected_order['total_harga']); ?></p>
                        </div>
                    `;
                    break;
                default:
                    instructions = '<div class="alert alert-warning">Instruksi pembayaran tidak tersedia</div>';
            }
            
            document.getElementById('paymentInstructions').innerHTML = instructions;
            new bootstrap.Modal(document.getElementById('paymentModal')).show();
        }
    </script>
</body>
</html> 