<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

$user_id = $_SESSION['user_id'];
$cart_data = [];
$total = 0;

// Ambil cart aktif dari database
$stmt = $pdo->prepare("SELECT * FROM carts WHERE user_id = ? AND status = 'active' LIMIT 1");
$stmt->execute([$user_id]);
$cart = $stmt->fetch();

if (!$cart) {
    setAlert('error', 'Keranjang belanja kosong!');
    redirect('cart.php');
}

// Ambil data cart items
$stmt = $pdo->prepare("
    SELECT ci.*, m.nama, m.harga, m.gambar, m.deskripsi, m.kategori
    FROM cart_items ci
    JOIN menu m ON ci.menu_id = m.id
    WHERE ci.cart_id = ?
");
$stmt->execute([$cart['id']]);
$cart_data = $stmt->fetchAll();

if (empty($cart_data)) {
    setAlert('error', 'Keranjang belanja kosong!');
    redirect('cart.php');
}

// Hitung total
foreach ($cart_data as &$item) {
    $item['subtotal'] = $item['harga'] * $item['quantity'];
    $total += $item['subtotal'];
}

// Ambil metode pembayaran yang tersedia
$stmt = $pdo->query("SELECT * FROM payment_methods WHERE status = 'aktif' ORDER BY nama");
$payment_methods = $stmt->fetchAll();

// Ambil data user
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $payment_method_id = $_POST['payment_method'] ?? '';
    $errors = [];
    if (empty($payment_method_id)) {
        $errors[] = 'Pilih metode pembayaran';
    }
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();
            // Buat order baru tanpa nomor_telepon dan catatan
            $stmt = $pdo->prepare("INSERT INTO orders (user_id, total_harga, payment_method_id) VALUES (?, ?, ?)");
            $stmt->execute([$user_id, $total, $payment_method_id]);
            $order_id = $pdo->lastInsertId();
            
            // Pindahkan cart items ke order items
            foreach ($cart_data as $item) {
                $stmt = $pdo->prepare("
                    INSERT INTO order_items (order_id, menu_id, quantity, harga_satuan, subtotal)
                    VALUES (?, ?, ?, ?, ?)
                ");
                $stmt->execute([$order_id, $item['menu_id'], $item['quantity'], $item['harga'], $item['subtotal']]);
            }
            
            // Update status cart menjadi checked_out
            $stmt = $pdo->prepare("UPDATE carts SET status = 'checked_out' WHERE id = ?");
            $stmt->execute([$cart['id']]);
            
            $pdo->commit();
            
            setAlert('success', 'Pesanan berhasil dibuat! Silakan lakukan pembayaran.');
            redirect("orders.php?order_id=$order_id");
            
        } catch (Exception $e) {
            $pdo->rollBack();
            setAlert('error', 'Terjadi kesalahan saat membuat pesanan!');
        }
    } else {
        setAlert('error', implode(', ', $errors));
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Restoran Lezat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <style>
        .payment-method-card {
            border: 2px solid #e9ecef;
            border-radius: 10px;
            padding: 15px;
            margin-bottom: 10px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .payment-method-card:hover {
            border-color: #0d6efd;
            background-color: #f8f9fa;
        }
        
        .payment-method-card.selected {
            border-color: #0d6efd;
            background-color: #e7f3ff;
        }
        
        .payment-method-card input[type="radio"] {
            display: none;
        }
        
        .payment-method-icon {
            font-size: 2rem;
            color: #6c757d;
        }
        
        .selected .payment-method-icon {
            color: #0d6efd;
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Restoran Lezat
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-house me-1"></i>
                            Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan Saya
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-credit-card me-2"></i>
                Checkout
            </h2>
            <a href="cart.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-2"></i>
                Kembali ke Keranjang
            </a>
        </div>

        <form method="POST" action="">
            <div class="row">
                <!-- Order Summary -->
                <div class="col-lg-4">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-receipt me-2"></i>
                                Ringkasan Pesanan
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($cart_data as $item): ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <small class="fw-bold"><?php echo htmlspecialchars($item['nama']); ?></small>
                                        <br>
                                        <small class="text-muted"><?php echo $item['quantity']; ?>x @ <?php echo formatPrice($item['harga']); ?></small>
                                    </div>
                                    <small class="fw-bold"><?php echo formatPrice($item['subtotal']); ?></small>
                                </div>
                            <?php endforeach; ?>
                            
                            <hr>
                            
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <strong>Total:</strong>
                                <strong class="text-primary fs-5"><?php echo formatPrice($total); ?></strong>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- User Info (replace Informasi Pengiriman) -->
                <div class="col-lg-8">
                    <div class="card mb-4">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-person me-2"></i>
                                Info Customer
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-2">
                                    <strong>Nama User:</strong> <?php echo htmlspecialchars($user['username']); ?>
                                </div>
                                <div class="col-md-6 mb-2">
                                    <strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Payment Methods -->
                    <div class="card mt-4">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-credit-card me-2"></i>
                                Pilih Metode Pembayaran
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($payment_methods as $method): ?>
                                <div class="payment-method-card" onclick="selectPaymentMethod(<?php echo $method['id']; ?>)">
                                    <input type="radio" name="payment_method" value="<?php echo $method['id']; ?>" id="payment_<?php echo $method['id']; ?>">
                                    <div class="d-flex align-items-center">
                                        <div class="me-3">
                                            <i class="bi <?php echo $method['icon']; ?> payment-method-icon"></i>
                                        </div>
                                        <div class="flex-grow-1">
                                            <h6 class="mb-1"><?php echo htmlspecialchars($method['nama']); ?></h6>
                                            <small class="text-muted"><?php echo htmlspecialchars($method['deskripsi']); ?></small>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Submit Button -->
                    <div class="card mt-4">
                        <div class="card-body">
                            <div class="d-grid">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="bi bi-check-circle me-2"></i>
                                    Buat Pesanan
                                </button>
                            </div>
                            <div class="text-center mt-3">
                                <small class="text-muted">
                                    Dengan menekan tombol di atas, Anda menyetujui syarat dan ketentuan yang berlaku
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
    <script>
        function selectPaymentMethod(methodId) {
            // Remove selected class from all cards
            document.querySelectorAll('.payment-method-card').forEach(card => {
                card.classList.remove('selected');
            });
            
            // Add selected class to clicked card
            event.currentTarget.classList.add('selected');
            
            // Check the radio button
            document.getElementById('payment_' + methodId).checked = true;
        }
        
        // Auto-select first payment method
        document.addEventListener('DOMContentLoaded', function() {
            const firstMethod = document.querySelector('.payment-method-card');
            if (firstMethod) {
                firstMethod.classList.add('selected');
                const radioId = firstMethod.querySelector('input[type="radio"]').id;
                document.getElementById(radioId).checked = true;
            }
        });
    </script>
</body>
</html> 