<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

if (!isLoggedIn() || isAdmin()) {
    redirect('../login.php');
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT username, email, role FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
if (!$user) {
    showAlert('User tidak ditemukan', 'danger');
    redirect('dashboard.php');
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil Saya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="../assets/css/style.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow">
                    <div class="card-body">
                        <h3 class="mb-4 text-center">Profil Saya</h3>
                        <ul class="list-group mb-4">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Username</span>
                                <span class="fw-bold"><?php echo htmlspecialchars($user['username']); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Email</span>
                                <span class="fw-bold"><?php echo htmlspecialchars($user['email']); ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <span>Role</span>
                                <span class="badge bg-primary text-uppercase"><?php echo htmlspecialchars($user['role']); ?></span>
                            </li>
                        </ul>
                        <a href="menu.php" class="btn btn-outline-primary w-100">Kembali ke Menu</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 