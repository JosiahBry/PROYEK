<?php
require_once '../includes/functions.php';
require_once '../config/database.php';

// Cek login
if (!isLoggedIn()) {
    redirect('../login.php');
}

if (isAdmin()) {
    redirect('../admin/dashboard.php');
}

$user_id = $_SESSION['user_id'];
$cart_data = [];
$total = 0;

// Ambil cart aktif dari database
$stmt = $pdo->prepare("SELECT * FROM carts WHERE user_id = ? AND status = 'active' LIMIT 1");
$stmt->execute([$user_id]);
$cart = $stmt->fetch();

if ($cart) {
    $stmt = $pdo->prepare("
        SELECT ci.*, m.nama, m.harga, m.gambar, m.deskripsi, m.kategori
        FROM cart_items ci
        JOIN menu m ON ci.menu_id = m.id
        WHERE ci.cart_id = ?
    ");
    $stmt->execute([$cart['id']]);
    $cart_data = $stmt->fetchAll();
    foreach ($cart_data as &$item) {
        $item['subtotal'] = $item['harga'] * $item['quantity'];
        $total += $item['subtotal'];
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Keranjang Belanja - Restoran Lezat</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white">
        <div class="container">
            <a class="navbar-brand" href="dashboard.php">
                <i class="bi bi-cup-hot-fill me-2"></i>
                Restoran Lezat
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="dashboard.php">
                            <i class="bi bi-house me-1"></i>
                            Beranda
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="menu.php">
                            <i class="bi bi-list-ul me-1"></i>
                            Menu
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="orders.php">
                            <i class="bi bi-cart me-1"></i>
                            Pesanan Saya
                        </a>
                    </li>
                </ul>
                <ul class="navbar-nav">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i>
                            <?php echo getUserName(); ?>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="profile.php">Profile</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="../logout.php">Logout</a></li>
                        </ul>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="container mt-4">
        <!-- Alert -->
        <?php $alert = getAlert(); ?>
        <?php if ($alert): ?>
            <div class="alert alert-<?php echo $alert['type']; ?> alert-dismissible fade show" role="alert">
                <?php echo $alert['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>
                <i class="bi bi-cart3 me-2"></i>
                Keranjang Belanja
            </h2>
            <a href="menu.php" class="btn btn-outline-primary">
                <i class="bi bi-plus-circle me-2"></i>
                Tambah Menu
            </a>
        </div>

        <?php if (empty($cart_data)): ?>
            <!-- Empty Cart -->
            <div class="text-center py-5">
                <i class="bi bi-cart-x text-muted" style="font-size: 4rem;"></i>
                <h4 class="text-muted mt-3">Keranjang Belanja Kosong</h4>
                <p class="text-muted">Belum ada menu yang dipilih</p>
                <a href="menu.php" class="btn btn-primary">
                    <i class="bi bi-list-ul me-2"></i>
                    Lihat Menu
                </a>
            </div>
        <?php else: ?>
            <!-- Cart Items -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="card">
                        <div class="card-body">
                            <?php foreach ($cart_data as $item): ?>
                                <div class="row align-items-center mb-3 pb-3 border-bottom">
                                    <div class="col-md-2">
                                        <img src="../assets/images/menu/<?php echo $item['gambar'] ?: 'default.jpg'; ?>" 
                                             alt="<?php echo htmlspecialchars($item['nama']); ?>" 
                                             class="img-fluid rounded">
                                    </div>
                                    <div class="col-md-4">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($item['nama']); ?></h6>
                                        <small class="text-muted"><?php echo htmlspecialchars($item['deskripsi']); ?></small>
                                        <br>
                                        <span class="category-badge"><?php echo ucfirst($item['kategori']); ?></span>
                                    </div>
                                    <div class="col-md-2">
                                        <span class="price"><?php echo formatPrice($item['harga']); ?></span>
                                    </div>
                                    <div class="col-md-2">
                                        <div class="quantity-control">
                                            <button type="button" class="quantity-btn" 
                                                    data-menu-id="<?php echo $item['menu_id']; ?>" 
                                                    data-change="decrease">-</button>
                                            <input type="number" class="quantity-input" 
                                                   value="<?php echo $item['quantity']; ?>" 
                                                   data-menu-id="<?php echo $item['menu_id']; ?>" 
                                                   min="0" max="99">
                                            <button type="button" class="quantity-btn" 
                                                    data-menu-id="<?php echo $item['menu_id']; ?>" 
                                                    data-change="increase">+</button>
                                        </div>
                                    </div>
                                    <div class="col-md-2 text-end">
                                        <span class="price"><?php echo formatPrice($item['subtotal']); ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Cart Summary -->
                <div class="col-lg-4">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="mb-0">
                                <i class="bi bi-receipt me-2"></i>
                                Ringkasan Pesanan
                            </h5>
                        </div>
                        <div class="card-body">
                            <?php foreach ($cart_data as $item): ?>
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <div>
                                        <small class="fw-bold"><?php echo htmlspecialchars($item['nama']); ?></small>
                                        <br>
                                        <small class="text-muted"><?php echo $item['quantity']; ?>x @ <?php echo formatPrice($item['harga']); ?></small>
                                    </div>
                                    <small class="fw-bold"><?php echo formatPrice($item['subtotal']); ?></small>
                                </div>
                            <?php endforeach; ?>
                            
                            <hr>
                            
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <strong>Total:</strong>
                                <strong class="text-primary fs-5"><?php echo formatPrice($total); ?></strong>
                            </div>
                            
                            <div class="d-grid gap-2">
                                <a href="checkout.php" class="btn btn-primary">
                                    <i class="bi bi-credit-card me-2"></i>
                                    Checkout
                                </a>
                                <a href="menu.php" class="btn btn-outline-secondary">
                                    <i class="bi bi-plus-circle me-2"></i>
                                    Tambah Menu
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/js/script.js"></script>
</body>
</html> 